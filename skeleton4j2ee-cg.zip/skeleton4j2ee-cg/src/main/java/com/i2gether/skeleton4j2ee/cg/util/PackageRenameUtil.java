package com.i2gether.skeleton4j2ee.cg.util;

import java.io.File;

public class PackageRenameUtil 
{
	public static final String SRC_DIR = "src";
	public static final String STRUTS_XML = SRC_DIR + "/" + "struts.xml";
	
	public static final String WAR_DIR = "war";
	public static final String WEB_INF_DIR = WAR_DIR + "/" +"WEB-INF";
	public static final String WEB_XML = WEB_INF_DIR + "/" +"web.xml";
	public static final String WEB_TEMPLATE = WEB_INF_DIR + "/" +"templates";
	//Caution: don't change the 'SRC_PACKAGE' until you don't know about it.
	public static final String SRC_PACKAGE = "org.zahangirbd";


	public static void renamePackage(String destPackage) throws Exception
	{
		if(destPackage == null
				|| destPackage.trim().length() == 0
				|| SRC_PACKAGE.equalsIgnoreCase(destPackage.trim()))
		{
			return;
		}
		
		String srcPackage = SRC_PACKAGE;
		//first we need to split into two package
		int dotindex = destPackage.indexOf('.');
		if(dotindex > 0)
		{
			String fpkg = destPackage.substring(0,dotindex);
			String lpkg = destPackage.substring(dotindex+1, destPackage.length());
			
			int sdotindex = srcPackage.indexOf('.');
			String sfpkg = srcPackage.substring(0,sdotindex);
			String slpkg = srcPackage.substring(sdotindex+1, srcPackage.length());

			//-------------------------SRC Change-----------------------
			//changing new package to each file in source directory
			File srcDir = new File(".", SRC_DIR + "/" + sfpkg);
			FileUtil.replaceInDir(srcDir, srcPackage, destPackage);
			//changing package directory
			//first last package directory rename
			FileUtil.renamePkgDir(SRC_DIR + "/" + sfpkg + "/" + slpkg, SRC_DIR + "/" + sfpkg + "/" + lpkg);
			//then first package directory rename
			FileUtil.renamePkgDir(SRC_DIR + "/" + sfpkg, SRC_DIR + "/" + fpkg);

			//now only Constants.java file need to be changed
			File contFile =  new File(".", SRC_DIR + "/" + fpkg + "/" + lpkg + "/common/Constants.java");
			FileUtil.replaceInFile(contFile, slpkg, lpkg);

			//changing struts.xml file
			File strutsxml = new File(".", STRUTS_XML);
			//first replacing full package
			FileUtil.replaceInDir(strutsxml, srcPackage, destPackage);
			//now only last package
			FileUtil.replaceInFile(strutsxml, slpkg, lpkg);

			//-------------------------WAR Change-----------------------
			//changing image source for new package
			//image, js and stype package directory is changing say war/zahangirbd to new war/newpackage
			FileUtil.renamePkgDir(WAR_DIR + "/" + slpkg, WAR_DIR + "/" + lpkg);
			
			//changing web.xml file for new package
			File webxml = new File(".", WEB_XML);
			//first replacing full package
			FileUtil.replaceInFile(webxml, srcPackage, destPackage );
			//now only last package
			FileUtil.replaceInFile(webxml,slpkg,lpkg);
		
			//all jsp file directive is changing according to new package
			File template = new File(".", WEB_TEMPLATE);
			FileUtil.replaceInDir(template, srcPackage, destPackage);
		}	
	}


}
