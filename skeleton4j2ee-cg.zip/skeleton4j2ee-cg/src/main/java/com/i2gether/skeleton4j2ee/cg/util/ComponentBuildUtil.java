package com.i2gether.skeleton4j2ee.cg.util;


import java.io.File;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.i2gether.skeleton4j2ee.cg.dto.FieldDTO;
import com.i2gether.skeleton4j2ee.cg.dto.FieldDTO.FileType;
import com.i2gether.skeleton4j2ee.cg.dto.FieldDTO.Type;

public class ComponentBuildUtil 
{
	public static final String WEB_DIR = "web";
	public static final String LEFTBAR_FILE = WEB_DIR + "/Home/Leftbar/HomePageLeftBar.jsp";		
	public static final String SRC_CG_DIR = ".";
	public static final String INPUT_DIR = SRC_CG_DIR + "/" + "input";
	public static final String INPUT_CONFIG_DIR = INPUT_DIR + "/" + "config";
	public static final String INPUT_JAVA_DIR = INPUT_DIR + "/" + "java";
	public static final String INPUT_JSP_DIR = INPUT_DIR + "/" + "jsp";
	public static final String INPUT_DBSCRIPT_DIR = INPUT_DIR + "/" + "dbscript";
	public static final String SRC_DIR_PATH = "src/main/java";
	public static final String SRC_STRUTS_XML = SRC_DIR_PATH + "/struts.xml";
	public static final String SRC_APPCONTEXT_XML = SRC_DIR_PATH + "/applicationContext.xml";
	private static final String CODE_TEMPLATE_TMP = "code-template.tmp";
	private static final String INPUT_TEMPLATE_TMP = INPUT_CONFIG_DIR + "/" + CODE_TEMPLATE_TMP;
	private static final String STRUTS_FILE_UPLOAD_XML = "struts-fileupload.xml";
	private static final String INPUT_STRUTS_FILE_UPLOAD = INPUT_CONFIG_DIR + "/" + STRUTS_FILE_UPLOAD_XML;
	
	public static final String OUTPUT_DIR = SRC_CG_DIR + "/" + "output";
	public static final String OUTPUT_JAVA_DIR = OUTPUT_DIR + "/" + "java";	
	public static final String PKG_COMPONENT_NAME = "sample";
	public static final String OUTPUT_JAVA_PROJ_DIR = OUTPUT_JAVA_DIR + "/" + PKG_COMPONENT_NAME;
	public static final String OUTPUT_JSP_DIR = OUTPUT_DIR + "/" + "jsp";
	public static final String OUTPUT_JSP_PROJ_DIR = OUTPUT_JSP_DIR + "/" + PKG_COMPONENT_NAME;
	public static final String OUTPUT_CONFIG_DIR = OUTPUT_DIR + "/" + "config";
	public static final String OUTPUT_CONFIG_APPCONTEXT_XML = OUTPUT_CONFIG_DIR + "/" + "applicationContext.xml";
	public static final String OUTPUT_CONFIG_STRUTS_XML = OUTPUT_CONFIG_DIR + "/" + "struts.xml";
	public static final String OUTPUT_CONFIG_DBSCRIPT = OUTPUT_CONFIG_DIR + "/" + "dbscript.sql";
	private static final String OUTPUT_CODE_TEMPLATE_TMP = OUTPUT_CONFIG_DIR + "/" + CODE_TEMPLATE_TMP;	
	private static final String OUTPUT_STRUTS_FILE_UPLOAD = OUTPUT_CONFIG_DIR + "/" + STRUTS_FILE_UPLOAD_XML;
	private static final String MAPPINGRESOURCES = "mappingResources";
	private static final String LIST_END_TAG = "</list>";
	private static final String BEANS_END_TAG = "</beans>";
	private static final String CUSTOM_FIELDS_TXT ="CUSTOM_FIELDS";
	private static final String JAVA_COMMENT_CUSTOM_FIELDS = "// " + CUSTOM_FIELDS_TXT + " //";
	private static final String HTML_COMMENT_CUSTOM_FIELDS = "<!-- " + CUSTOM_FIELDS_TXT + " -->";
	private static final String PROPERTY_COMMENT_CUSTOM_FIELDS = "# " + CUSTOM_FIELDS_TXT + " #";
	private static final String JAVA_CUSTOM_SEARCH_FIELD1 = "// $CUSTOM_SEARCH_FIELD1$ //";
	private static final String JAVA_CUSTOM_SEARCH_FIELD2 = "// $CUSTOM_SEARCH_FIELD2$ //";
	private static final String FILE_UPLOAD_POSTFIX_FILE_NAME = "FileName";
	private static final String FILE_UPLOAD_POSTFIX_CONTENT_TYPE = "ContentType";
	private static final String FILE_UPLOAD_POSTFIX_FILE_SIZE = "FileSize";
	private static final String JAVA_ACTION_VALIDATION_BLOCK = "//$JAVA_ACTION_VALIDATION_BLOCK$//";
	private static final String FILE_UPLOAD_PROPERTIES_BLOCK = "#$FILE_UPLOAD_PROPERTIES_BLOCK$#";
	
	//Caution: don't change the 'SRC_PACKAGE' until you don't know about it.
	private static final String SRC_PACKAGE = "com.mycompany.myproject";
	

	public enum Database{MSSQL,MySQL};
	public static Database SELECTED_DATABASE = Database.MSSQL;
	
	/**
	 * This method is used to create a component based on provided source package, destination package, component, component field list and 
	 * an information whether all generated code will be merged into 'src' and 'war' directory or not. 
	 * @param destPkg The destination package like 'com.mycompany.myproject'
	 * @param component The component name like 'user' all characters must be lower case
	 * @param fields The filed list which will be added into this component
	 * @param projectHomeDir is the project home directory. If it is null then no files will be copied.
	 * @throws Exception if any problem occurs
	 */
	public static void buildComponent(String destPkg, String component, List<FieldDTO> fields, String projectHomeDir) throws Exception {
		buildComponent(destPkg,component,fields,projectHomeDir,null);
	}
	
	public static void buildUploadComponent(String destPkg, String component, String projectHomeDir, String fileUploadDir) throws Exception{
		List<FieldDTO> list = new ArrayList<FieldDTO>();
		FieldDTO fileFieldDTO = new FieldDTO(component, Type.FILE_UOLOAD);
		fileFieldDTO.setFileType(FileType.IMAGE);
		list.add(fileFieldDTO);
		buildUploadComponent(destPkg, component, list, projectHomeDir, fileUploadDir);
	}

	public static void buildUploadComponent(String destPkg, String component, List<FieldDTO> fields, String projectHomeDir, String fileUploadDir) throws Exception{
		buildComponent(destPkg, component, fields, projectHomeDir, fileUploadDir);
	}

	private static void buildComponent(String destPkg, String component, List<FieldDTO> fields, String projectHomeDir, String fileUploadDir) throws Exception
	{				
		String srcPkg = SRC_PACKAGE;
		//generate output directory
		System.out.println("buildComponent(): copying input sourc files to output directory....");
		copyToOutputDir();
		System.out.println("buildComponent(): input source is copied to output directory.");
				
		//changing source files
		System.out.println("buildComponent(): changing all java source files...");
		changeSource(srcPkg, destPkg, component);
		System.out.println("buildComponent(): changing all java source files are completed.");
		
		//changing jsp files
		System.out.println("buildComponent(): changing all jsp files...");
		changeJspFiles(srcPkg, destPkg, component);
		System.out.println("buildComponent(): changing all jsp files are completed.");
		
		//changing configuration files
		System.out.println("buildComponent(): changing struts.xml file...");
		changeConfig(srcPkg, destPkg, component);
		System.out.println("buildComponent(): changing struts.xml file is completed.");

		//adding new fields
		System.out.println("buildComponent(): adding new fields into DTO...");
		addfields(destPkg, component,fields);
		System.out.println("buildComponent(): adding new fields into DTO are completed.");
		
		//if there is file upload then need to change the service classes
		boolean isFileUpload = isFileUploadComponent(fields);
		FileType fileType = getFileUploadFileType(fields);
		
		System.out.println("buildComponent(): changing service class for file upload...");
		changeJavaSourcesForFileUpload(destPkg, component,fields,isFileUpload);
		System.out.println("buildComponent(): changing service class for file upload is completed.");
		
		System.out.println("buildComponent(): changing configuration file for file upload...");
		changeConfigForFileUpload(destPkg, component,fields, fileUploadDir, isFileUpload);
		System.out.println("buildComponent(): changing configuration file for file upload is completed.");
		
		//if it is normal component then delete extra GetFile
		deleteExtraFiles(component, isFileUpload);
				
		//now if everything is passed and source is generated into 'src-cg/output' folder
		if(projectHomeDir != null)
		{
			System.out.println("buildComponent(): adding all generated sources into 'src' and 'war'...");
			copyOutputToProjectHomeDir(projectHomeDir, destPkg, component, isFileUpload, fileType);
			System.out.println("buildComponent(): adding all generated sources into 'src' and 'war' is completed.");
		}
		
		//create a link
		System.out.println("buildComponent(): creating link for this component...");
		createLink(component, projectHomeDir);
		System.out.println("buildComponent(): creating link for this component is completed.");

		System.out.println("buildComponent(): output folder = " + OUTPUT_DIR);
		System.out.println("buildComponent(): DONE.");
	}
	
	private static FileType getFileUploadFileType(List<FieldDTO> fields) {
		if(fields == null 
				|| fields.size() == 0)
		{
			return FileType.NONE;
		}

		for(FieldDTO dto:fields){
			if(dto.getFileType() != FileType.NONE){
				return dto.getFileType();
			}
		}
		
		return FileType.NONE;
	}

	private static void deleteExtraFiles(String component, boolean isFileUpload) {

		//delete code-template.tmp
		File templateFile = new File(OUTPUT_CODE_TEMPLATE_TMP);
		templateFile.delete();
				
		if(!isFileUpload){
			String cmpPkgName = ComponentUtil.getPkgName(component);
			String cmp = ComponentUtil.getComponentName(component);
			File getFile = new File(OUTPUT_JAVA_DIR, cmpPkgName + "/action/Get" + cmp + ".java");
			getFile.delete();
			
			File strutsFileUpload = new File(OUTPUT_STRUTS_FILE_UPLOAD);
			strutsFileUpload.delete();
		}
	}

	private static void changeConfigForFileUpload(String destPkg, String component, List<FieldDTO> fields, String fileUploadDir, boolean isFileUpload) throws Exception {
		
		String cmp = ComponentUtil.getPkgName(component);
		
		File confFile = new File(OUTPUT_CONFIG_APPCONTEXT_XML);			
		String datastr = FileUtil.getFileData(confFile);
		String uploadPath = "    <property name=\"uploadDirectory\">" +
    							"    \t<value>" + fileUploadDir + "</value>" + 
    						"    </property>";

		if(isFileUpload){
			datastr = datastr.replace("<!-- $SET_UPLOAD_DIRECTORY_PATH$ -->", uploadPath);
		}else{
			datastr = datastr.replace("<!-- $SET_UPLOAD_DIRECTORY_PATH$ -->", "");
		}
		
		//now write the app config file
		FileUtil.writeIntoFile(confFile, datastr);	
		
		
		File strutsFile = new File(OUTPUT_CONFIG_STRUTS_XML);
		datastr = FileUtil.getFileData(strutsFile);
		
		String stackRef = "<interceptor-ref name=\"" + cmp + "FileUploadStack\"/>";
		if(isFileUpload){
			datastr = datastr.replace("<!-- $STRUTS_FILE_UPLOAD_STACK_REF$ -->", stackRef);
		}else{
			datastr = datastr.replace("<!-- $STRUTS_FILE_UPLOAD_STACK_REF$ -->", "");
		}
		
		if(isFileUpload){
			String uploadFileGetBlock = getBlockFromTemplate("<!-- $STRUTS_UPLOADED_FILE_GET_BLOCK$ -->");
			uploadFileGetBlock = getComponentReplaced(uploadFileGetBlock, component);
			uploadFileGetBlock = uploadFileGetBlock.replace(SRC_PACKAGE, destPkg);
			datastr = datastr.replace("<!-- $STRUTS_UPLOADED_FILE_GET_BLOCK$ -->", uploadFileGetBlock);
		}else{
			datastr = datastr.replace("<!-- $STRUTS_UPLOADED_FILE_GET_BLOCK$ -->", "");
		}
		
		//now write the struts file
		FileUtil.writeIntoFile(strutsFile, datastr);	
	}


	private static void changeJavaSourcesForFileUpload(String destPkg, String component, List<FieldDTO> fields, boolean isFileUpload) throws Exception {
		
		String cmpPkgName = ComponentUtil.getPkgName(component);
		String cmp = ComponentUtil.getComponentName(component);
		
		File interfaceFile = new File(OUTPUT_JAVA_DIR, cmpPkgName + "/service/" + cmp + "Service.java");			
		String datastr = FileUtil.getFileData(interfaceFile);
		if(isFileUpload){
			datastr = datastr.replace("//$JAVA_SERVICE_INTERFACE_FUNCTION_BLOCK$//", "String get" + cmp + "Path(String uniqueCode);");
		}else{
			datastr = datastr.replace("//$JAVA_SERVICE_INTERFACE_FUNCTION_BLOCK$//", "");
		}
		
		//now write the interface file
		FileUtil.writeIntoFile(interfaceFile, datastr);	
		
		
		//change the impl
		File implFile = new File(OUTPUT_JAVA_DIR, cmpPkgName + "/service/" + cmp + "ServiceImpl.java");	
		datastr = FileUtil.getFileData(implFile);
	
		String block1 = getBlockFromTemplate("//$JAVA_SERVICE_FUNCTION_BLOCK1$//");
		block1 = getComponentReplaced(block1, component);
		if(isFileUpload){
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK1$//", block1);
		}else{
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK1$//", "");
		}

		String block2 = getBlockFromTemplate("//$JAVA_SERVICE_FUNCTION_BLOCK2$//");
		block2 = getComponentReplaced(block2, component);
		if(isFileUpload){
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK2$//", block2);
		}else{
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK2$//", "");
		}

		String block3 = getBlockFromTemplate("//$JAVA_SERVICE_FUNCTION_BLOCK3$//");
		block3 = getComponentReplaced(block3, component);
		if(isFileUpload){
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK3$//", block3);
		}else{
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK3$//", "");
		}

		String block4 = getBlockFromTemplate("//$JAVA_SERVICE_FUNCTION_BLOCK4$//");
		block4 = getComponentReplaced(block4, component);
		if(isFileUpload){
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK4$//", block4);
		}else{
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK4$//", "");
		}

		String block5 = getBlockFromTemplate("//$JAVA_SERVICE_FUNCTION_BLOCK5$//");
		block5 = getComponentReplaced(block5, component);
		if(isFileUpload){
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK5$//", block5);
		}else{
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK5$//", "");
		}

		String block6 = getBlockFromTemplate("//$JAVA_SERVICE_FUNCTION_BLOCK6$//");
		block6 = getComponentReplaced(block6, component);
		if(isFileUpload){
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK6$//", block6);
		}else{
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK6$//", "");
		}

		
		String fileUtilStr = "import " + destPkg + ".common.util.FileUtils;";
		String exceptionStr = "\t\tcatch(BusinessRuleViolationException e){\n\t\t\tthrow e;\n\t\t}";
		if(isFileUpload){
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK7$//", exceptionStr);
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK8$//", exceptionStr);
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK9$//", fileUtilStr);
		}else{
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK7$//", "");
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK8$//", "");
			datastr = datastr.replace("//$JAVA_SERVICE_FUNCTION_BLOCK9$//", "");
		}
	
		//write the implementation file
		FileUtil.writeIntoFile(implFile, datastr);			
	}
	
	private static String getComponentReplaced(String str, String component){
		if(!StringUtils.isValid(str)){
			return "";
		}

		String refCmp = ComponentUtil.getComponentName(PKG_COMPONENT_NAME);
		String destCmp = ComponentUtil.getComponentName(component);
		str = str.replaceAll(refCmp, destCmp);

		String refPkgCmp = ComponentUtil.getPkgName(PKG_COMPONENT_NAME);
		String destPkgCmp = ComponentUtil.getPkgName(component);
		str = str.replaceAll(refPkgCmp, destPkgCmp);
		
		return str;
	}


	private static void copyOutputToProjectHomeDir(String projectHomeDir, String destPkg, String component, boolean isFileUpload, FileType uploadFileType) throws Exception 
	{
		//now I need to do the following tasks.
		//1. copy java source from 'output/java/component' to 'projectHomeDir' + '/src/main/java/' + 'destPkg' + '/component' 
		//2. copy jsp files from output/jsp/component' to 'projectHomeDir' + 'web/component'	
		//3. copy the struts.xml action from 'output/config/struts.xml' to 'projectHomeDir' + '/src/main/java/strust.xml'
		//3. copy the applicationContext.xml beans&hbm from 'output/config/applicationContext.xml' to 'projectHomeDir' + '/src/main/java/applicationContext.xml'

		if(destPkg == null
				|| destPkg.trim().length() == 0)
		{
			return;
		}
		
		//getting project home
		String srcDir = projectHomeDir;
		if(!projectHomeDir.endsWith("/")){
			srcDir += "/";
		}
		
		//getting actual source path
		srcDir += SRC_DIR_PATH + "/";
		
		//getting package path
		String copyToDir = destPkg.replace(".", "/");
		if(!copyToDir.endsWith("/")){
			copyToDir += "/";
		}
		srcDir += copyToDir;
		
		File toDir = new File (srcDir);
		File fromDir = new File(".", OUTPUT_JAVA_DIR);
		
		System.out.println("copyOutputToProjectHomeDir(): java files are being copied to 'src/main/java' folder...");
		FileUtil.copyDirectory(fromDir, toDir);
				
		toDir = new File (projectHomeDir, WEB_DIR);
		fromDir = new File(".", OUTPUT_JSP_DIR);

		System.out.println("copyOutputToProjectHomeDir(): jsp files are being copied to 'web/' folder...");
		FileUtil.copyDirectory(fromDir, toDir);
		System.out.println("copyOutputToProjectHomeDir(): jsp files copying to 'web/' folder is completed.");

		System.out.println("copyOutputToProjectHomeDir(): struts actions are being copied...");
		copyStrutsXmlContent(component, isFileUpload, projectHomeDir, uploadFileType);
		System.out.println("copyOutputToProjectHomeDir(): struts actions copying completed.");

		System.out.println("copyOutputToProjectHomeDir(): applicationContext are being copied...");
		copyApplicationContextContent(projectHomeDir, destPkg, component);
		System.out.println("copyOutputToProjectHomeDir(): applicationContexts copying completed.");		
	}

	private static void copyApplicationContextContent(String projetHomeDir, String deskPkg, String component) throws Exception {

		File file1 = new File(".", OUTPUT_CONFIG_APPCONTEXT_XML);
		//getting all actions from output file
		String outputContent = FileUtil.getFileData(file1);
		
		//generate the hbm file content 
		String hbmStr = "<value>" + deskPkg.replace(".", "/") + "/" + ComponentUtil.getPkgName(component) + "/dto/" + ComponentUtil.getComponentName(component) + "DTO.hbm.xml</value>";
		
		//getting original file content
		File file2 = new File(projetHomeDir, SRC_APPCONTEXT_XML);
		String data2 = FileUtil.getFileData(file2);
		
		int mappingResourcesIndex = data2.indexOf(MAPPINGRESOURCES);
		if(mappingResourcesIndex<=0){
			System.err.println("copyApplicationContextContent(): '</package>' not found in " + SRC_APPCONTEXT_XML);
			throw new Exception(MAPPINGRESOURCES + " not found in " + SRC_APPCONTEXT_XML);			
		}
		
		String str1 = "";
		String str2 = "";
		int listTagEndIndex = data2.indexOf(LIST_END_TAG, mappingResourcesIndex);
		if(listTagEndIndex > 0){
			str1 = data2.substring(0, listTagEndIndex);
			//mid = hbm value
			str2 = data2.substring(listTagEndIndex, data2.length());
		}else{
			System.err.println("copyApplicationContextContent(): " + LIST_END_TAG + " not found in " + SRC_APPCONTEXT_XML);
			throw new Exception("copyApplicationContextContent(): " + LIST_END_TAG + " not found in " + SRC_APPCONTEXT_XML);						
		}
		//now making merge for hbm 
		String merge = str1 + "        " + hbmStr + "\n\t" + str2;
		
		//since original file content contains hbm content, so replacing them
		//for safe case
		outputContent = outputContent.replace("<!-- MAPPING_START -->", " ");
		outputContent = outputContent.replace(hbmStr, "");
		outputContent = outputContent.replace("<!-- MAPPING_END -->", " ");
		
		int beanIndex = outputContent.indexOf("<!-- BEAN_START -->");
		if(beanIndex > 0){
			outputContent = outputContent.substring(beanIndex, outputContent.length());			
		}
		outputContent = outputContent.replace("<!-- BEAN_START -->", " ");
		outputContent = outputContent.replace("<!-- BEAN_END -->", " ");
		
		int lastBeansIndex = merge.lastIndexOf(BEANS_END_TAG);
		if(lastBeansIndex <= 0){
			System.err.println("copyApplicationContextContent(): " + BEANS_END_TAG + " not found in " + SRC_APPCONTEXT_XML);
			throw new Exception("copyApplicationContextContent(): " + BEANS_END_TAG + " not found in " + SRC_APPCONTEXT_XML);									
		}
		merge = merge.substring(0, lastBeansIndex);
		merge += outputContent + BEANS_END_TAG;
		
		if(file2.delete())
		{
			FileUtil.writeIntoFile(file2, merge);
		}
		else
		{
			System.err.println("copyApplicationContextContent(): struts actions copying FAILED.");
			throw new Exception("File:" + file2.getAbsolutePath() + " is not deleted. So new write will not work.");
		}		
	}

	private static void copyStrutsXmlContent(String component, boolean isFileUpload, String projetHomeDir, FileType uploadFileType) throws Exception 
	{
		File file1 = new File(".", OUTPUT_CONFIG_STRUTS_XML);
		//getting all actions from output file
		String data1 = FileUtil.getFileData(file1);
		
		//getting original file content
		File file2 = new File(projetHomeDir, SRC_STRUTS_XML);
		String originalFileContent = FileUtil.getFileData(file2);
		
		String str1 = "";
		String str2 = "";
		int j1 = originalFileContent.lastIndexOf("</package>");
		if(j1 > 0)
		{
			str1 = originalFileContent.substring(0, j1);
			//mid = actions
			str2 = originalFileContent.substring(j1, originalFileContent.length());
		}
		else
		{
			System.err.println("copyStrutsXmlContent(): '</package>' not found in " + SRC_STRUTS_XML);
			throw new Exception("'</package>' not found in " + SRC_STRUTS_XML);						
		}
		
		String merge = new String(str1 + "\n" + data1 + "\n" + str2);
		String dataToSaved = new String(merge);
		
		if(isFileUpload){
		
			String cmp = ComponentUtil.getPkgName(component);
			String strutsFileUploadContent = getStrutsFileUploadContent();
			strutsFileUploadContent = strutsFileUploadContent.replace("fileUploadStack", cmp + "FileUploadStack");
					
			//<!--  $STRUTS_FILE_UPLOAD_STACK_ALLOWED_TYPES$ -->
			String preFix = "<param name=\"allowedTypes\">"; 
			String postFix = "</param>";
			String allowedFileTypes = "";
			if(uploadFileType == FileType.IMAGE){
				allowedFileTypes = preFix + "image/jpeg,image/jpg,image/gif,image/png" + postFix;
			}else if(uploadFileType == FileType.EXCEL){
				allowedFileTypes = preFix + "application/vnd.ms-excel" + postFix;
			}else if(uploadFileType == FileType.PDF){
				allowedFileTypes = preFix + "application/pdf" + postFix;
			}else if(uploadFileType == FileType.TXT){
				allowedFileTypes = preFix + "text/plain" + postFix;
			}else if(uploadFileType == FileType.CSV){
				allowedFileTypes = preFix + "text/csv" + postFix;
			}
			strutsFileUploadContent = strutsFileUploadContent.replace("<!--  $STRUTS_FILE_UPLOAD_STACK_ALLOWED_TYPES$ -->", allowedFileTypes);
			
			String startPkg = "struts-default";
			String resultTypesEndTag = "</result-types>";
			int startPkgIndex = merge.lastIndexOf(startPkg);
					
			if(startPkgIndex > 0){
				int i = merge.indexOf(resultTypesEndTag, startPkgIndex + startPkg.length());
				int indexOfSplit = -1;
				if(i > 0){
					indexOfSplit = i + resultTypesEndTag.length();
				}else{
					i = merge.indexOf(">", startPkgIndex + startPkg.length());
					if(i>0){
						indexOfSplit = i + 1;
					}
				}
				
				if(indexOfSplit > 0){
					str1 = merge.substring(0, indexOfSplit);			
					str2 = merge.substring(indexOfSplit, merge.length());					
					dataToSaved = str1 + "\n" + strutsFileUploadContent + "\n" + str2;
				}
				
			}
		
		}
		
		if(file2.delete())
		{
			FileUtil.writeIntoFile(file2, dataToSaved);
		}
		else
		{
			System.err.println("copyStrutsXmlContent(): struts actions copying FAILED.");
			throw new Exception("File:" + file2.getAbsolutePath() + " is not deleted. So new write will not work.");
		}
	}


	private static void createLink(String component, String projectHomeDir) throws Exception 
	{
		String cmp = ComponentUtil.getPkgName(component);
		String componentName = ComponentUtil.getComponentName(component);
		String lnk = "\t<tr>\n\t\t<td class='bottom_border'>&nbsp;<font size='2'><b><a href='" + cmp + ".action?operationType=search'>" + componentName + " Management</a></b></font></td>\n\t</tr>\n";
		
		File file = new File(".", OUTPUT_JSP_DIR + "/" + "link.txt");
		FileUtil.writeIntoFile(file, lnk);
		
		
		//now no need to create a link in left home page as link are generated according to database
		//5. copy a link from 'output/jsp/link.txt' to 'war/WEB-INF/templates/linklist.jsp'
		/*
		if(projectHomeDir != null)
		{
			System.out.println("createLink(): link is being added to linklist.jsp...");
			File oldfile = new File(projectHomeDir, LEFTBAR_FILE);
			String olddata = FileUtil.getFileData(oldfile);
			String data = olddata;
			int indexOfTable = olddata.lastIndexOf("</table>");
			if(indexOfTable > 0){
				data = olddata.substring(0, indexOfTable);
				data += lnk + "</table>";
			}
			
			if(oldfile.delete())
			{
				FileUtil.writeIntoFile(oldfile, data);
				System.out.println("createLink(): link addition into linklist.jsp is completed.");
			}
			else
			{
				System.err.println("createLink(): link addition into linklist.jsp is FAILED.");
				throw new Exception("File:" + oldfile.getAbsolutePath() + " is not deleted. So new write will not work.");
			}
		}
		*/
	}
	
	private static void writeFileContentByDeleting(File file, String data ) throws Exception{
		if(file.delete())
		{
			FileUtil.writeIntoFile(file, data);
		}
		else
		{
			System.err.println("writeFileContentByDeleting(): File was not able to delete.");
			throw new Exception("File:" + file.getAbsolutePath() + " is not deleted. So new write will not work.");			
		}		
	}
	
	private static void addfields(String destPkg, String component, List<FieldDTO> fields) throws Exception 
	{
		
		if(fields == null 
				|| fields.size() == 0)
		{
			return;
		}
	
		String cmp = ComponentUtil.getPkgName(component);
		if(isFileUploadComponent(fields)){
			//need to add four fields			
			FieldDTO file = new FieldDTO(cmp, Type.FILE);
			fields.add(file);
			
			FieldDTO contentType = new FieldDTO(cmp + FILE_UPLOAD_POSTFIX_CONTENT_TYPE, Type.STRING);
			fields.add(contentType);

			FieldDTO fileName = new FieldDTO(cmp + FILE_UPLOAD_POSTFIX_FILE_NAME, Type.STRING);
			fields.add(fileName);

			FieldDTO fileSize = new FieldDTO(cmp + FILE_UPLOAD_POSTFIX_FILE_SIZE, Type.LONG);
			fields.add(fileSize);
		}
		
		//add getter setter 
		System.out.println("addfields(): Adding setter and getter...");
		addGetterSetter(component, fields);
		System.out.println("addfields(): Adding setter and getter is completed.");		
		
		//add hibernate configuration
		System.out.println("addfields(): Adding hibernate configuration...");
		addHibernateConfiguration(component, fields);
		System.out.println("addfields(): Adding hibernate configuration is completed.");

		//add columns into dbscript c
		System.out.println("addfields(): Adding columns int dbscript...");
		addColumnsIntoDbScript(component, fields);
		System.out.println("addfields(): Adding columns int dbscript.");

		//change in SampleCommonAction.
		System.out.println("addfields(): Adding search squery in common action class...");
		addSqlQueryParams(component, fields);
		System.out.println("addfields():Adding search squery in common action class is completed.");

		//change in SampleEditAction.
		System.out.println("addfields(): Adding search squery in edit action class...");
		addValidations(component, fields);
		System.out.println("addfields():Adding search squery in edit action class is completed.");

		System.out.println("addfields(): Adding fileds into jsp file...");
		addFieldsIntoJsp(destPkg, component, fields);
		System.out.println("addfields(): Adding fileds into jsp file is completed.");
		
		System.out.println("addfields(): Adding fileds package.properties file...");
		addFieldsIntoProperties(component, fields);
		System.out.println("addfields(): Adding fileds package.properties file is completed.");		
	}

	private static String getTemplateContent() throws Exception{
		File templateFile = new File(INPUT_TEMPLATE_TMP);
		String templateData = FileUtil.getFileData(templateFile);			
		return templateData;
	}

	private static String getStrutsFileUploadContent() throws Exception{
		File strutsFile = new File(INPUT_STRUTS_FILE_UPLOAD);
		String fileUploadContent = FileUtil.getFileData(strutsFile);			
		return fileUploadContent;
	}

	private static String getBlockFromTemplate(String blockName) throws Exception{
		String templateData = getTemplateContent();
		String validationBlock = StringUtils.getBlock(templateData, blockName);		
		return validationBlock;
	}

	private static void addValidations(String component, List<FieldDTO> fields) throws Exception {
		if(fields == null 
				|| fields.size() == 0)
		{
			return;
		}
		
		
		if(!isFileUploadComponent(fields)){
		
			String validationBlock = getBlockFromTemplate(JAVA_ACTION_VALIDATION_BLOCK);
			String refCmp = ComponentUtil.getComponentName(PKG_COMPONENT_NAME);
			String destCmp = ComponentUtil.getComponentName(component);
			validationBlock = validationBlock.replaceAll(refCmp, destCmp);

			String refPkgCmp = ComponentUtil.getPkgName(PKG_COMPONENT_NAME);
			String destPkgCmp = ComponentUtil.getPkgName(component);
			validationBlock = validationBlock.replaceAll(refPkgCmp, destPkgCmp);
			
			File editActionFile = new File(OUTPUT_JAVA_DIR, destPkgCmp + "/action/" + destCmp + "EditAction.java");			
			String datastr = FileUtil.getFileData(editActionFile);			
			datastr = datastr.replace(JAVA_ACTION_VALIDATION_BLOCK, validationBlock);
			
			FileUtil.writeIntoFile(editActionFile, datastr);			
		}
		
	}

	private static boolean isFileUploadComponent(List<FieldDTO> fields){
		if(fields == null 
				|| fields.size() == 0)
		{
			return false;
		}

		for(FieldDTO dto:fields){
			if(dto.getType() == Type.FILE_UOLOAD){
				return true;
			}
		}

		return false;
	}

	private static void addColumnsIntoDbScript(String component, List<FieldDTO> fields) throws Exception {
		if(fields == null 
				|| fields.size() == 0)
		{
			return;
		}
		
		File dbScriptFile = new File(".", OUTPUT_CONFIG_DBSCRIPT);
		String datastr = FileUtil.getFileData(dbScriptFile);
		
		String columnStr = "";
		for(FieldDTO dto:fields){
			//no setter/getter for file upload, or File
			if(dto.getType() == Type.FILE_UOLOAD 
					|| dto.getType() == Type.FILE){
				continue;
			}

			columnStr += "  " + dto.getFieldName() + " " + dto.getType().getSqlType() + " DEFAULT NULL,\n";
		}
		
		//replacing data
		datastr = datastr.replace(PROPERTY_COMMENT_CUSTOM_FIELDS, columnStr);
		
		String cmp = ComponentUtil.getComponentName(component);
		if(SELECTED_DATABASE == Database.MSSQL){
			
			datastr = datastr.replace("#$SQL_ID_GENERATOR$#", "IDENTITY");
			String startStr = "IF EXISTS(SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = '" + cmp + "s') DROP TABLE [" + cmp +"s];\n";
			//IF EXISTS(SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Users') DROP TABLE [Users];
			//--for SQL 2005/2008, clustered index is automatically created on Primary key 'componentId'
			//CREATE UNIQUE INDEX INDEX_Users_uniqueCode ON [Users]([uniqueCode]);
			String lastStr = ";\n--for SQL 2005/2008, clustered index is automatically created on Primary key 'componentId'\n" +
							 "CREATE UNIQUE INDEX INDEX_" + cmp +"s_uniqueCode ON [" + cmp +"s]([uniqueCode]);";
			
			datastr = startStr + datastr + lastStr;

		}else if(SELECTED_DATABASE == Database.MySQL){
			datastr = datastr.replace("#$SQL_ID_GENERATOR$#", "AUTO_INCREMENT");
			String startStr = "DROP TABLE IF EXISTS " + cmp + "s;\n";
			//DROP TABLE IF EXISTS Samples;
			//ENGINE = InnoDB; #here componentId is automatically clustered index in MySQL 5.0
			String lastStr = "\nENGINE = InnoDB; #here componentId is automatically clustered index in MySQL 5.0\n" + 
								"CREATE UNIQUE INDEX INDEX_" + cmp + "s_uniqueCode ON " + cmp + "s (uniqueCode);";
			datastr = startStr + datastr + lastStr;
		}else{
			datastr = datastr.replace(PROPERTY_COMMENT_CUSTOM_FIELDS, columnStr);
			datastr += ";";
		}
		
		//now function code need to be added into DB 
		datastr +="\n\n";
		
		//following parts are related to generate function code 
		String cmpPkg = ComponentUtil.getPkgName(component);

		//search function
		String sql = createFunctionCode(cmpPkg+"search", cmp+"s", cmpPkg + ".action?operationType=search", 1);
		datastr += sql + "\n\n";
		
		//get function, in this moment paused
		//sql = createFunctionCode(cmpPkg+"get", "View " + cmp, cmpPkg + ".action?operationType=prompt" ,0);
		//datastr += sql + "\n\n";

		//add function
		sql = createFunctionCode(cmpPkg+"add", "Add " + cmp, cmpPkg + ".action?operationType=add", 0);
		datastr += sql + "\n\n";

		//modify function
		sql = createFunctionCode(cmpPkg+"modify", "Modify " + cmp, cmpPkg + ".action?operationType=modify", 0);
		datastr += sql + "\n\n";

		//delete function
		sql = createFunctionCode(cmpPkg+"delete", "Delete " + cmp, cmpPkg + ".action?operationType=delete", 0);
		datastr += sql + "\n\n";			

		//delete function
		sql = createFunctionCode(cmpPkg+"deleteselected", "Delete All Selected " + cmp, cmpPkg + ".action?operationType=deleteselected", 0);
		datastr += sql + "\n\n";			

		//writing data into file
		writeFileContentByDeleting(dbScriptFile, datastr);
	}


	private static String createFunctionCode(String functionCodeName, String displayName, String actionUrl, int isMenu)
	{
		String sql = "INSERT INTO Functioncodes(uniqueCode, displayName, codeNumber, actionUrl, isMenu, status, version) " + 
		  				"\n SELECT '" + functionCodeName + "','" + displayName + "',MAX(codeNumber)+1,'" + actionUrl + "'," + isMenu + ",1,0 " +
		  				"\n FROM Functioncodes;";
		return sql;
	}

	private static void addSqlQueryParams(String component, List<FieldDTO> fields) throws Exception {

		String cmp = ComponentUtil.getPkgName(component);
		String cmp2 = ComponentUtil.getComponentName(component);

		File actionFile = new File(".", OUTPUT_JAVA_DIR + "/" + cmp + "/" + "action" + "/" + cmp2 + "CommonAction.java");
		String datastr = FileUtil.getFileData(actionFile);

		String queryParams = "\"";
		boolean isFileUpload = false;
		for(FieldDTO dto:fields){
			if(dto.getType() == Type.FILE_UOLOAD){
				isFileUpload = true;
			}else{
				
				//there is no mapping for FILE
				if(dto.getType() == Type.FILE){
					continue;
				}
				queryParams += " , a." + dto.getFieldName();
			}
		}		
		queryParams += " \" + ";
		
		//replacing data
		datastr = datastr.replace(JAVA_COMMENT_CUSTOM_FIELDS, queryParams);
		
		String searchField = "\" a.uniqueCode \"";
		if(isFileUpload){
			searchField = "\" a." + cmp + FILE_UPLOAD_POSTFIX_FILE_NAME + " \"";
		}
		searchField += " + ";
		datastr = datastr.replace(JAVA_CUSTOM_SEARCH_FIELD1, searchField);
		
		if(SELECTED_DATABASE == Database.MSSQL){
			
			//starting select block
			String selectBlock = getBlockFromTemplate("//$JAVA_SEARCH_FUNCTION_MSSQL_BLOCK1$//");
			datastr = datastr.replace("//$JAVA_SEARCH_FUNCTION_SQL_BLOCK1$//", selectBlock);
			
			String endBlock = getBlockFromTemplate("//$JAVA_SEARCH_FUNCTION_MSSQL_BLOCK2$//");
			datastr = datastr.replace("//$JAVA_SEARCH_FUNCTION_SQL_BLOCK2$//", endBlock);
			
		}else if(SELECTED_DATABASE == Database.MySQL){
			
			String selectStr = "String sqlQuery = \" SELECT \";";
			datastr = datastr.replace("//$JAVA_SEARCH_FUNCTION_SQL_BLOCK1$//", selectStr);	
			
			//adding ordering and pagination block from sample code
			String block = getBlockFromTemplate("//$JAVA_SEARCH_FUNCTION_MYSQL_BLOCK1$//");
			datastr = datastr.replace("//$JAVA_SEARCH_FUNCTION_SQL_BLOCK2$//", block);	
			
			//only used for MySQL
			datastr = datastr.replace(JAVA_CUSTOM_SEARCH_FIELD2, searchField);
		}
		
		
		//writing into file
		writeFileContentByDeleting(actionFile, datastr);
	}

	private static void addHibernateConfiguration(String component, List<FieldDTO> fields) throws Exception {
		String cmp = ComponentUtil.getPkgName(component);
		String cmp2 = ComponentUtil.getComponentName(component);

		File hbmFile = new File(".", OUTPUT_JAVA_DIR + "/" + cmp + "/" + "dto" + "/" + cmp2 + "DTO.hbm.xml");
		String datastr = FileUtil.getFileData(hbmFile);

		String propertiesStr = "";
		for(FieldDTO dto:fields){
			
			//no setter/getter for file upload, or File
			if(dto.getType() == Type.FILE_UOLOAD 
					|| dto.getType() == Type.FILE){
				continue;
			}
			
			propertiesStr += "\n\t  <property name=\"" + dto.getFieldName() + "\" type=\"" + dto.getType().getHibernateType() + "\" column=\"" + dto.getFieldName() + "\"/>";
		}
		//replacing data
		datastr = datastr.replace(HTML_COMMENT_CUSTOM_FIELDS, propertiesStr);
		
		//writing data into file
		writeFileContentByDeleting(hbmFile, datastr);

	}

	private static void addFieldsIntoProperties(String component, List<FieldDTO> fields) throws Exception 
	{
		if(component == null 
				|| fields == null 
				|| fields.size() == 0)
		{
			return;
		}
		
		String cmp = ComponentUtil.getPkgName(component);
		File propertyFile = new File(".", OUTPUT_JAVA_DIR + "/" + cmp + "/" + "action" + "/package.properties");
		String datastr = FileUtil.getFileData(propertyFile);
		
		String propertiesStr = "";
		String nameprefix = cmp+"DTO.";
		boolean isFileUpload = false;
		for(FieldDTO dto:fields)
		{
			if(dto.getType() == Type.FILE_UOLOAD){
				isFileUpload = true;
			}else{
				String key = nameprefix + dto.getFieldName(); 
				String value = getPropertyDisplayName(dto);
				propertiesStr += key + " = " + value + "\n";
			}
		}
		
		//replacing data
		datastr = datastr.replace(PROPERTY_COMMENT_CUSTOM_FIELDS, propertiesStr);
		
		if(isFileUpload){
			String propertiesBlock = getBlockFromTemplate(FILE_UPLOAD_PROPERTIES_BLOCK);
			datastr = datastr.replace(FILE_UPLOAD_PROPERTIES_BLOCK, propertiesBlock);
		}else{
			datastr = datastr.replace(FILE_UPLOAD_PROPERTIES_BLOCK, "");
		}
				
		//writing data into file
		writeFileContentByDeleting(propertyFile, datastr);
	}

	private static String getPropertyDisplayName(FieldDTO dto)
	{
		String ret = dto.getFieldName();
		if(dto.getDisplayName() != null 
				&& dto.getDisplayName().trim().length() > 0)
		{
			ret = dto.getDisplayName().trim();
		}
		else
		{
			byte [] bts = ret.getBytes();
			int i = 0;
			for(byte b:bts)
			{
				if(Character.isUpperCase(b))
				{
					break;
				}
				i++;
			}
			
			if( i < ret.length())
			{
				//found
				String str1 = ret.substring(0,i);
				String str2 = ret.substring(i,ret.length());
				ret = ComponentUtil.getPropertyName(str1) + " " + str2;
			}
			else
			{
				ret = ComponentUtil.getPropertyName(ret);
			}			
		}
		return ret;
	}

	private static void addFieldsIntoJsp(String destPkg, String component, List<FieldDTO> fields) throws Exception 
	{
		if(component == null 
				|| fields == null 
				|| fields.size() == 0)
		{
			return;
		}
		
		String cmp = ComponentUtil.getComponentName(component);
		String pkgcmp = ComponentUtil.getPkgName(component);
		File jspFile = new File(".", OUTPUT_JSP_DIR + "/" + cmp + "/Modify/" + cmp + "Entry.jsp");
		String datastr = FileUtil.getFileData(jspFile);
	
		//if file upload and file type is image then we need to show getURL
		boolean isFileUpload = isFileUploadComponent(fields);
		
		//form multipart addition
		String keyString1 = "<s:form action=\"" + pkgcmp + "edit\"";
		String keyString2 = new String(keyString1) + ">";
		if(isFileUpload){
			 String replacedStr = keyString1 +" enctype=\"multipart/form-data\" method=\"post\">";
			 datastr = datastr.replace(keyString2, replacedStr);
		}
		
		if(isFileUploadComponent(fields)){
			boolean isImageType=false;
			for(FieldDTO dto:fields){
				if(dto.getFileType() == FileType.IMAGE){
					isImageType = true;
				}
			}
			
			if(isImageType){
				String getFileStr = "<tr><td/><td><img src='get" + cmp + ".action?fileId=<s:property value=\"" + pkgcmp + "DTO.uniqueCode\"/>'/></td></tr>";
				datastr = datastr.replace("<!-- FILE_UPLOAD_GET_FILE -->", getFileStr);
			}
		}

		//for normal component, uniqueCode is textField but for fileUpload it is hidden field
		String dynamicField = "<s:textfield key=\"" + pkgcmp + "DTO.uniqueCode\"/>";
		if(isFileUpload){
			dynamicField = "<s:hidden key=\"" + pkgcmp + "DTO.uniqueCode\"/>";
		}
		datastr = datastr.replace("<!-- CUSTOM_DYNAMIC_FIELD -->", dynamicField);
		
		
		String struts2fields = "\n";
		String columHeaders = "\n";
		
		for(FieldDTO dto:fields){
			
			//no setter/getter for file upload, or File
			if(dto.getType() == Type.FILE_UOLOAD ){
				continue;
			}

			if(dto.getType() == Type.FILE){
				struts2fields += "\t\t\t\t\t\t<s:file key=\""+pkgcmp+"DTO."+dto.getFieldName()+"\"/>\n";	
			}else if(dto.getType() == Type.BOOLEAN){
				struts2fields += "\t\t\t\t\t\t<s:checkbox key=\""+pkgcmp+"DTO."+dto.getFieldName()+"\"/>\n";	
			}
			else{
				
				if(isFileUpload){
					//then for three properties there will be no struts field
					//sampleContentType,sampleFileName,sampleFileSize
					if(dto.getFieldName().endsWith(FILE_UPLOAD_POSTFIX_CONTENT_TYPE)
							|| dto.getFieldName().endsWith(FILE_UPLOAD_POSTFIX_FILE_NAME)
							|| dto.getFieldName().endsWith(FILE_UPLOAD_POSTFIX_FILE_SIZE)){
						;//nothing to do
					}else{
						struts2fields += "\t\t\t\t\t\t<s:textfield key=\""+pkgcmp+"DTO."+dto.getFieldName()+"\"/>\n";	
					}					
				}else{
					struts2fields += "\t\t\t\t\t\t<s:textfield key=\""+pkgcmp+"DTO."+dto.getFieldName()+"\"/>\n";
				}				
										
			}
			
			if(dto.getType() == Type.FILE){
				; //nothing
			}else{
				columHeaders +="\t\t\t<td valign='middle' height='23'>\n" +
								"\t\t\t <a href='#'>\n" +
								"\t\t\t\t<s:i18n name='" + destPkg + "." + pkgcmp + ".action." + cmp + "Action'>\n"+
								"\t\t\t\t\t<s:text name='" + pkgcmp + "DTO." + dto.getFieldName() + "'></s:text>\n"+
								"\t\t\t\t</s:i18n>\n"+
								"\t\t\t </a>\n" + 
								"\t\t\t</td>\n";
			}
		}		
		//replacing data
		datastr = datastr.replace(HTML_COMMENT_CUSTOM_FIELDS, struts2fields);		
		//writing data
		writeFileContentByDeleting(jspFile, datastr);
		
		//writing headers in search page
		jspFile = new File(".", OUTPUT_JSP_DIR + "/" + cmp + "/Search/ColumnHeaderWithCheckBox.jsp");
		datastr = FileUtil.getFileData(jspFile);
		//replacing data
		datastr = datastr.replace(HTML_COMMENT_CUSTOM_FIELDS, columHeaders);
		//writing data
		writeFileContentByDeleting(jspFile, datastr);		
	}

	private static void addGetterSetter(String component, List<FieldDTO> fields) throws Exception 
	{
		String cmp = ComponentUtil.getPkgName(component);
		String cmp2 = ComponentUtil.getComponentName(component);
		
		File dtoFile = new File(".", OUTPUT_JAVA_DIR + "/" + cmp + "/" + "dto" + "/" + cmp2 + "DTO.java");
		String datastr = FileUtil.getFileData(dtoFile);

		String attributesStr = "";

		for(FieldDTO dto:fields)
		{
			//no setter/getter for file upload
			if(dto.getType() == Type.FILE_UOLOAD){
				continue;
			}
			
			attributesStr += "\n\tprivate " + dto.getType().getJavaType() + " " + dto.getFieldName() + ";\n";
		}						

		for(FieldDTO dto:fields)
		{
			//no setter/getter for file upload
			if(dto.getType() == Type.FILE_UOLOAD){
				continue;
			}

			if(dto.getType() == Type.BOOLEAN)
			{
				attributesStr += "\n" +
				"\t" + "public " + dto.getType().getJavaType() + " is" + ComponentUtil.getPropertyName(dto.getFieldName())+ "() {\n" +
				"\t\t" + "return this." + dto.getFieldName()+";\n" +
				"\t}\n";					
			}
			else
			{
				attributesStr += "\n" +
				"\t" + "public " + dto.getType().getJavaType() + " get" + ComponentUtil.getPropertyName(dto.getFieldName())+ "() {\n" +
				"\t\t" + "return this." + dto.getFieldName()+";\n" +
				"\t}\n";					
			}
			
			attributesStr += "\n" +
					"\t" + "public void set" + ComponentUtil.getPropertyName(dto.getFieldName())+ "( " + dto.getType().getJavaType()+ " " + dto.getFieldName() + " ) {\n" +
							"\t\tthis." + dto.getFieldName() + "=" + dto.getFieldName() + ";\n" +
									"\t}\n";
		}
		
		//replacing data
		datastr = datastr.replace(JAVA_COMMENT_CUSTOM_FIELDS, attributesStr);
		
		//writing data into file
		writeFileContentByDeleting(dtoFile, datastr);
	}

	private static void copyToOutputDir() throws IOException
	{
		//first deleting existing output directory
		File outDir = new File(".", OUTPUT_DIR);
		FileUtil.delete(outDir);
		
		//creating new output directory
		outDir.mkdir();
		
		//copy the input file to output folder for changing.
		File inDir = new File(".", INPUT_DIR);
		FileUtil.copyDirectory(inDir, outDir);
		
		//now need to delete if any *.svn file exists from outDir
		FileUtil.deleteSvnFolder(outDir);
	}
	
	private static boolean isValidPkgChange(String srcPkg, String destPkg)
	{
		if(srcPkg == null
				|| srcPkg.trim().length() == 0
				|| destPkg == null
				|| destPkg.trim().length() == 0
				|| srcPkg.trim().equalsIgnoreCase(destPkg.trim()))
		{
			return false;
		}
		else
		{	
			return true;
		}
	}
	
	private static void changeConfig(String srcPkg, String destPkg, String component) throws Exception
	{
		//changing configuration files
		File srcDir = new File(".", OUTPUT_CONFIG_DIR);
		
		if(isValidPkgChange(srcPkg, destPkg)){

			//source pkg is replacing with destination pkg
			FileUtil.replaceInDir(srcDir, srcPkg, destPkg);

		}
		
		//component name is replacing as a pkg name	normally it starts with lower case later. Like 'sample'
		FileUtil.replaceInDir(srcDir, ComponentUtil.getPkgName(PKG_COMPONENT_NAME), ComponentUtil.getPkgName(component));
		
		//Component name is replacing as a component name. normally it starts with upper case later. Like 'Sample'
		FileUtil.replaceInDir(srcDir, ComponentUtil.getComponentName(PKG_COMPONENT_NAME), ComponentUtil.getComponentName(component));

		//now just changing specific file 'applicationContext.xml'
		File appContexFile = new File(".", OUTPUT_CONFIG_APPCONTEXT_XML);
		String srcStr = new String(srcPkg);
		srcStr = srcStr.replace(".", "/");
		String destStr = new String(destPkg);
		destStr = destStr.replace(".", "/");
		FileUtil.replaceInFile(appContexFile, srcStr, destStr);		
	}
	
	private static void changeSource(String srcPkg, String destPkg, String component) throws Exception
	{
		//changing new package to each file in source directory
		File srcDir = new File(".", OUTPUT_JAVA_PROJ_DIR);
		
		if(isValidPkgChange(srcPkg, destPkg))
		{	
			//source pkg is replacing with destination pkg
			FileUtil.replaceInDir(srcDir, srcPkg, destPkg);
		}
		else
		{
			System.out.println("changeSource(): srcPkg and destPkg is not valid package. So nothing is changed related to package");
		}
		
		//component name is replacing as a pkg name	
		FileUtil.replaceInDir(srcDir, ComponentUtil.getPkgName(PKG_COMPONENT_NAME), ComponentUtil.getPkgName(component));
		
		//Component name is replacing
		FileUtil.replaceInDir(srcDir, ComponentUtil.getComponentName(PKG_COMPONENT_NAME), ComponentUtil.getComponentName(component));
				
		//now we need to replace the java file name.
		FileUtil.renameJavaJspFiles(srcDir, ComponentUtil.getComponentName(PKG_COMPONENT_NAME), ComponentUtil.getComponentName(component));
	
		//rename component directory
		FileUtil.renamePkgDir(OUTPUT_JAVA_PROJ_DIR, OUTPUT_JAVA_DIR + "/" + ComponentUtil.getPkgName(component));
	}

	private static void changeJspFiles(String srcPkg, String destPkg, String component) throws Exception
	{
		//changing new package to each file in source directory
		File srcDir = new File(".", OUTPUT_JSP_DIR);
		
		if(isValidPkgChange(srcPkg, destPkg))
		{
			//source pkg is replacing with destination pkg
			FileUtil.replaceInDir(srcDir, srcPkg, destPkg);
			
			int dotindex = destPkg.lastIndexOf('.');
			if(dotindex > 0)
			{
				String lpkg = destPkg.substring(dotindex+1, destPkg.length());
				
				int sdotindex = srcPkg.lastIndexOf('.');
				String slpkg = srcPkg.substring(sdotindex+1, srcPkg.length());

				//source pkg is replacing with destination pkg
				FileUtil.replaceInDir(srcDir, slpkg, lpkg);
			}
			else
			{
				System.err.println("changeJspFiles(): destPkg is not valid package. It must have two packages");
				throw new Exception("destPkg is not valid package. It must have two packages.");																				
			}
		}
		else
		{
			System.out.println("changeJspFiles(): srcPkg and destPkg is not valid package. So nothing is changed related to package");
		}
		
		//component name is replacing as a pkg name	
		FileUtil.replaceInDir(srcDir, ComponentUtil.getPkgName(PKG_COMPONENT_NAME), ComponentUtil.getPkgName(component));
		
		//Component name is replacing
		FileUtil.replaceInDir(srcDir, ComponentUtil.getComponentName(PKG_COMPONENT_NAME), ComponentUtil.getComponentName(component));

		//now we need to replace the java file name.
		FileUtil.renameJavaJspFiles(srcDir, ComponentUtil.getComponentName(PKG_COMPONENT_NAME), ComponentUtil.getComponentName(component));

		//rename component directory
		FileUtil.renamePkgDir(OUTPUT_JSP_PROJ_DIR, OUTPUT_JSP_DIR + "/" + ComponentUtil.getComponentName(component));
	}

}
