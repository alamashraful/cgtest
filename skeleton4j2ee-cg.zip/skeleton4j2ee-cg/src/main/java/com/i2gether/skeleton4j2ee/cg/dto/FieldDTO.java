package com.i2gether.skeleton4j2ee.cg.dto;

public class FieldDTO 
{
	public enum FileType{
		IMAGE,
		EXCEL,
		PDF,
		CSV,
		TXT,
		NONE
	}
	public enum Type
			{ 
				BOOLEAN("Boolean", "boolean", "bit"), 
				SHORT("Short", "short","number"), 
				INT("Integer","int","int"), 
				LONG("Long", "long", "bigint"), 
				DOUBLE("Double","double", "float"), 
				FLOAT("Float", "float", "float"), 
				STRING("String", "string", "varchar(128)"), 
				DATE("java.util.Date", "timestamp", "datetime"), 
				CALENDER("java.util.Calendar", "calendar", "datetime"), 
				LOCALE("java.util.Locale", "locale", "varchar(128)"),
				TIMEZONE("java.util.TimeZone", "timezone", "varchar(128)"),
				CURRENCY("java.util.Currency", "currency", "varchar(128)"),
				CLOB("java.sql.Clob", "clob", "CLOB"),
				BLOB("java.sql.Blob", "blob", "MEDIUMBLOB"),
				FILE("java.io.File", "serializable", "binary field"), //special handling will be used for upload file in a directory
				FILE_UOLOAD("java.io.File", "serializable", "binary field"), //special handling will be used for upload file in a directory
				JAVA_OBJECT("Object", "serializable", "binary field"),
				BYTE_ARRAY("byte [] ", "binary", "binary field"),
				JAVA_CLASS("Class","class","varchar(512)");
				
				private String javaType;
				private String hibernatType;
				private String sqlType;
				//private FileType fileType;
				private Type(String javaType, String hibernatType, String sqlType){
					this.javaType = javaType;
					this.hibernatType = hibernatType;
					this.sqlType = sqlType;
				}
				
				public String getJavaType(){
					return this.javaType;
				}
				
				public String getHibernateType(){
					return this.hibernatType;
				}
				
				public String getSqlType(){
					return this.sqlType;
				}
				
		};

	private String fieldName;
	private String displayName;
	private Type type;
	private FileType fileType; //only used for file upload module
	
	public FieldDTO()
	{}
	
	public FieldDTO(String fieldName, Type type)
	{
		this.fieldName = fieldName;
		this.type = type;
	}

	public FieldDTO(String fieldName, String displayName, Type type)
	{
		this.fieldName = fieldName;
		this.type = type;
		this.displayName = displayName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public Type getType() {
		return type;
	}
	public void setType(Type type) {
		this.type = type;
	}
	public FileType getFileType() {
		return fileType;
	}

	public void setFileType(FileType fileType) {
		this.fileType = fileType;
	}

}
