package com.i2gether.skeleton4j2ee.cg.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class FileUtil 
{
	/**
	 * This method is used to delete a file or directory
	 * @param file
	 */
	public static void delete(File file)
	{
		if(file == null)
		{
			return;
		}
		
		if(!file.exists())
		{
			return;
		}
		
		if(file.isFile())
		{
			if(file.delete())
			{
				;
			}
			else
			{
				System.err.println("file = " + file.getName() + " is not deleted.");
			}
		}
		else
		{
			File files[] = file.listFiles();
			for(File f:files)
			{
				delete(f);
			}
			
			//now delete directory
			if(file.delete())
			{
				;
			}
			else
			{
				System.err.println("file = " + file.getName() + " is not deleted.");
			}
		}
	}

	public static void copyDirectory(File sourceLocation , File targetLocation) throws IOException 
	{
        
        if (sourceLocation.isDirectory()) 
        {
            if (!targetLocation.exists()) 
            {
	            System.out.println("copyDirectory(): " + targetLocation.getName() + " directory is creating...");	
                targetLocation.mkdir();
            }
            
            String[] children = sourceLocation.list();
            for (int i=0; i<children.length; i++) 
            {
                copyDirectory(new File(sourceLocation, children[i]), new File(targetLocation, children[i]));
            }
        } 
        else 
        {
        	System.out.println("copyDirectory(): " + sourceLocation.getName() + " file is being copied...");
            InputStream in = new FileInputStream(sourceLocation);
            OutputStream out = new FileOutputStream(targetLocation);
            
            // Copy the bits from instream to outstream
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
            in.close();
            out.close();
        }
    }
	
	public static void renamePkgDir(String spkg, String dpkg) 
	{
		if(spkg == null 
				|| spkg.trim().length() == 0
				|| dpkg == null
				|| dpkg.trim().length() == 0
				|| spkg.trim().equals(dpkg.trim()))
		{
			return;
		}
		
		System.out.println("renamePkgDir(): rename '" + spkg + "' with '" + dpkg + "'");

		File sFPkgDir = new File(".", spkg);
		File dFPkgDir = new File(".", dpkg);
		renamePkgDir(sFPkgDir,dFPkgDir);
	}

	public static void renamePkgDir(File sFPkgDir, File dFPkgDir) 
	{
		if(sFPkgDir == null 
				|| dFPkgDir == null)
		{
			return;
		}
		
		sFPkgDir.renameTo(dFPkgDir);
	}

	public static void renameJavaJspFiles(File src, String srcComponent, String destComponent) 
	{		
		if(src == null
				|| (!src.exists()))
		{
			return;
		}
		
		if(srcComponent == null
				|| srcComponent.trim().length() == 0
				|| destComponent == null
				|| destComponent.trim().length() == 0
				|| srcComponent.trim().equals(destComponent.trim()))
		{
			return;
		}
		
		if(src.isFile())
		{
			String s = src.getName();
			String n = s.replaceAll(srcComponent, destComponent);
			System.out.println("renameJavaFile(): rename '" + s + "' with '" + n + "'");

			File nf = new File(src.getParent(), n);
			src.renameTo(nf);
		}
		else
		{
			File files [] = src.listFiles();
			if(files != null)
			{
				for (File f:files)
				{
					renameJavaJspFiles(f, srcComponent, destComponent);
				}
			}
		}
		
	}

	/**
	 * This method is used to replace 'src' string with 'dest' string into all
	 * files within this directory
	 * @param srcDir The directory 
	 * @param src The source string which will be replaced
	 * @param dest The destination string which will be used to replace
	 */
	public static void replaceInDir(File srcDir, String src, String dest) throws Exception
	{
		if(srcDir == null 
				|| src == null 
				|| src.trim().length() == 0
				|| dest == null
				|| dest.trim().length() == 0
				|| src.trim().equals(dest.trim()))
		{
			return;
		}
		
		System.out.println("replaceInDir(): replacing of '" + src + "' with '" + dest + "' in all files of '" + srcDir.getName() + "' directory.");
		
		if(srcDir.isDirectory())
		{
			File flist[] = srcDir.listFiles();
			if(flist != null)
			{
				for (File f:flist)
				{
					if(f.isFile())
					{
						//System.out.println("file = " + f.getName());
						replaceInFile(f, src, dest);
					}
					else
					{
						//System.out.println("dir = " + f.getName());
						replaceInDir(f,src,dest); 
					}
				}
			}
			else
			{
				System.out.println("flist of '" + srcDir + "' is null ");
			}
		}
		else
		{
			replaceInFile(srcDir,src, dest);
		}
		
	}

	/**
	 * This method is used to replace 'src' string with 'dest' string into all
	 * string in this file
	 * @param srcFile The source file
	 * @param src The source string which will be replaced
	 * @param dest The destination string which will be used to replace
	 */
	public static void replaceInFile(File srcFile, String src, String dest) throws Exception  
	{	
		if(srcFile == null 
				|| src == null 
				|| src.trim().length() == 0
				|| dest == null
				|| dest.trim().length() == 0
				|| src.trim().equals(dest.trim()))
		{
			return;
		}

		System.out.println("replaceInFile(): replacing of '" + src + "' with '" + dest + "' in '" + srcFile.getName() + "' file.");
		File pDir = srcFile.getParentFile();
		String tmpFileName = "tmp";
		File tmpFile = new File (pDir, tmpFileName);
		
		BufferedReader in = null;
		BufferedWriter out = null;
		
		try 
		{
			if(!tmpFile.createNewFile())
			{
				return;
			}
			
			FileReader fReader = new FileReader(srcFile);
			FileWriter fWriter = new FileWriter(tmpFile);
			in = new BufferedReader(fReader);
			out = new BufferedWriter(fWriter);
			
			String str = null;
			while ((str = in.readLine()) != null)
			{
				str = str.replaceAll(src, dest);
				
				//creating new line and then 
				out.write(str);
				out.newLine();
			}
			
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
			throw e;
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			throw e;
		}
		finally
		{
			if(in != null)
			{
				try 
				{
					in.close();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
			}
			
			if(out != null)
			{
				try 
				{
					out.close();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}				
			}
		}
		
		if(tmpFile.exists())
		{
			if(srcFile.delete())
			{
				//System.out.println(tmpFile.getName() + " is renaming to " +  srcFile.getName());
				tmpFile.renameTo(srcFile);
			}
		}		
	}

	public static void writeIntoFile(File file, String str) throws Exception
	{
		if(file == null 
				|| str == null 
				|| str.trim().length() == 0)
		{
			return;
		}

		try 
		{
			OutputStream out = new FileOutputStream(file);
			for(int i = 0; i < str.getBytes().length; i++)
			{
				out.write(str.getBytes()[i]);
			}
			out.close();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
			throw e;
		}
	}
	
	public static String getFileData(File file) throws Exception
	{
		StringBuilder data = new StringBuilder();
		
		try 
		{
			
			InputStream in = new FileInputStream(file);
            // Copy the bits from instream to outstream
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                
            	for(int i=0; i<len; i++)
            	{
            		data.append((char)buf[i]);
            	}
            }
            in.close();
			
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
			throw e;
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
			throw e;
		}
		
		//now we have data
		return data.toString();
	}

	public static void writeIntoFile(File file, Properties prop, String comment)throws Exception 
	{
		if(file == null 
				|| prop == null 
				|| prop.isEmpty())
		{
			return;
		}

		OutputStream out = new FileOutputStream(file);
		prop.store(out, comment);
		out.close();
	}

	//this method is used to delete all the file with the given regex
	public static void deleteSvnFolder(File file) 
	{
		if(file == null)
		{
			return;
		}
		
		if(!file.exists())
		{
			return;
		}
		
		if(file.isFile())
		{
			String name = file.getName();
			if(RegexUtil.isValidSvnFile(name))
			{
				if(file.delete())
				{
					System.out.println("file = " + file.getName() + " is deleted.");
				}
				else
				{
					System.err.println("file = " + file.getName() + " is not deleted.");
				}				
			}
			//else nothing to do.
		}
		else
		{
			String name = file.getName();
			if(RegexUtil.isValidSvnFile(name))
			{	
				File files[] = file.listFiles();
				for(File f:files)
				{
					delete(f);
				}

				if(file.delete())
				{
					System.out.println("file = " + file.getName() + " is deleted.");
				}
				else
				{
					System.err.println("file = " + file.getName() + " is not deleted.");
				}
			}
			else
			{
				File files[] = file.listFiles();
				for(File f:files)
				{
					deleteSvnFolder(f);
				}
				//we are not deleting any directory here
			}
		}		
	}

	//this method is used to delete all the file with the given regex
	public static void delete(File file, String regex) 
	{
		if(file == null)
		{
			return;
		}
		
		if(!file.exists())
		{
			return;
		}
		
		if(file.isFile())
		{
			String name = file.getName();
			if(RegexUtil.isValidSvnFile(name))
			{
				if(file.delete())
				{
					System.out.println("file = " + file.getName() + " is deleted.");
				}
				else
				{
					System.err.println("file = " + file.getName() + " is not deleted.");
				}				
			}
			//else nothing to do.
		}
		else
		{
			File files[] = file.listFiles();
			for(File f:files)
			{
				delete(f, regex);
			}

			//now delete directory
			String name = file.getName();
			if(RegexUtil.isValidSvnFile(name))
			{	
				if(file.delete())
				{
					System.out.println("file = " + file.getName() + " is deleted.");
				}
				else
				{
					System.err.println("file = " + file.getName() + " is not deleted.");
				}
			}
		}		
	}

}
