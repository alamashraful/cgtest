package com.i2gether.skeleton4j2ee.cg;

import java.util.ArrayList;
import java.util.List;

import com.i2gether.skeleton4j2ee.cg.dto.FieldDTO;
import com.i2gether.skeleton4j2ee.cg.dto.FieldDTO.Type;
import com.i2gether.skeleton4j2ee.cg.util.ComponentBuildUtil;
import com.i2gether.skeleton4j2ee.cg.util.ComponentBuildUtil.Database;


public class Main 
{
	public static void test()
	{
		//String destPkg = "com.i2gether.niv";
		String destPkg = "com.hsbc.prc";
		String []pkgs = destPkg.split("[.]");
		String copyToDir = "";
		boolean isFirst = true;
		for(String str:pkgs)
		{
			if(isFirst)
			{
				isFirst = false;
				copyToDir += str;
			}
			else
			{
				copyToDir += "/" + str;
			}			
		}
		System.out.println("copyToDir = " + copyToDir);

	}
	
	public static void createGeneralComponent()throws Exception{
		//String DEST_PACKAGE = "com.i2gether.niv";
		String DEST_PACKAGE = "com.hsbc.uccm";
		
		//all must be lowercase
		String COMPONENT = "reconciliationDetails";

		String projectHomeDir = null;	
		ComponentBuildUtil.SELECTED_DATABASE = Database.MSSQL;
		
		//PackageRenameUtil.renamePackage(DEST_PACKAGE);				
		ComponentBuildUtil.buildComponent(DEST_PACKAGE, COMPONENT, getComponentFields(), projectHomeDir);
	}

	public static void createUploadComponent()throws Exception{
		String DEST_PACKAGE = "com.i2gether.niv";
		
		//all must be lowercase
		String COMPONENT = "contentShareFiles";

		String projectHomeDir = null;		
		
		String uploadDirectory = "D:/installed-softwares/apache-tomcat-6.0.33/upload";
		
		//PackageRenameUtil.renamePackage(DEST_PACKAGE);				
		ComponentBuildUtil.buildUploadComponent(DEST_PACKAGE, COMPONENT, projectHomeDir, uploadDirectory);
	}

	public static void main(String[] args) throws Exception
	{
		//test();		
		createGeneralComponent();		
		//createUploadComponent();
	}
	
	public static List<FieldDTO> getComponentFields()
	{
		List<FieldDTO> fields = new ArrayList<FieldDTO>();
		
		//name already present by uniqueCode
		
		FieldDTO f2 = new FieldDTO("slipId", Type.LONG);
		fields.add(f2);
		
		FieldDTO f3 = new FieldDTO("fundId", Type.LONG);
		fields.add(f3);		
		
		
		FieldDTO f4 = new FieldDTO("reconciliationAmount", Type.FLOAT);
		fields.add(f4);		
		
		FieldDTO f5 = new FieldDTO("slipOutstandingAmount", Type.FLOAT);
		fields.add(f5);
		
		
		FieldDTO f6 = new FieldDTO("fundOutstandingAmount", Type.STRING);
		fields.add(f6);
		
		/*
		FieldDTO f7 = new FieldDTO("endTime", Type.CALENDER);
		fields.add(f7);
		
	
		FieldDTO f8 = new FieldDTO("absentCheckStartTime", Type.CALENDER);
		fields.add(f8);
		
		
		FieldDTO f9 = new FieldDTO("absentCheckEndTime", Type.CALENDER);
		fields.add(f9);
		
		
		FieldDTO f10 = new FieldDTO("publicationPlace", Type.STRING);
		fields.add(f10);
		
		FieldDTO f11 = new FieldDTO("noOfCopies", Type.INT);
		fields.add(f11);

		FieldDTO f12 = new FieldDTO("series", Type.DOUBLE);
		fields.add(f12);

		FieldDTO f13 = new FieldDTO("volumeNo", Type.DOUBLE);
		fields.add(f13);

		FieldDTO f14 = new FieldDTO("isbnNumber", Type.STRING);
		fields.add(f14);

		FieldDTO f15 = new FieldDTO("source", Type.STRING);
		fields.add(f15);

		FieldDTO f16 = new FieldDTO("price", Type.FLOAT);
		fields.add(f16);

		FieldDTO f17 = new FieldDTO("itemType", Type.STRING);
		fields.add(f17);

		FieldDTO f18 = new FieldDTO("generalNote", Type.STRING);
		fields.add(f18);

		FieldDTO f19 = new FieldDTO("language", Type.STRING);
		fields.add(f19);

		FieldDTO f20 = new FieldDTO("groupId", Type.LONG);
		fields.add(f20);
			
		FieldDTO f21 = new FieldDTO("libraryName", Type.STRING);
		fields.add(f21);
		
		FieldDTO f22 = new FieldDTO("campusId", Type.LONG);
		fields.add(f22);
		
		FieldDTO f23 = new FieldDTO("schoolId", Type.LONG);
		fields.add(f23);
		
		FieldDTO f24 = new FieldDTO("leaveStatus", Type.STRING);
		fields.add(f24);

	
		FieldDTO f25 = new FieldDTO("contactNumber", Type.STRING);
		fields.add(f25);
		 */

		return fields;
		
	}
}
