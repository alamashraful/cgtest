package com.i2gether.skeleton4j2ee.cg.util;

public class ComponentUtil 
{
	public static String getPkgName(String component)
	{
		if(component == null)
		{
			throw new IllegalArgumentException("component name could not be null");
		}
		
		return component.toLowerCase();
	}

	public static String getComponentName(String component)
	{
		if(component == null)
		{
			throw new IllegalArgumentException("component name could not be null");
		}

		if(component.trim().length() <= 1)
		{
			throw new IllegalArgumentException("component name is invalid. At least 2 character needs");
		}

		String upper = component.toUpperCase();
		String lower = component.toLowerCase();
		
		String cmp = upper.substring(0,1) + lower.substring(1,lower.length());
		return cmp;
	}

	public static String getPropertyName(String property)
	{
		if(property == null)
		{
			throw new IllegalArgumentException("component name could not be null");
		}

		if(property.trim().length() <= 1)
		{
			throw new IllegalArgumentException("component name is invalid. At least 2 character needs");
		}

		String upper = property.toUpperCase();
		
		String cmp = upper.substring(0,1) + property.substring(1,property.length());
		return cmp;
	}

	public static void main(String[] args) {
		String name = "fileUpload";
		System.out.println("pkgname = " + ComponentUtil.getPkgName(name));
		System.out.println("component = " + ComponentUtil.getComponentName(name));
	}
}
