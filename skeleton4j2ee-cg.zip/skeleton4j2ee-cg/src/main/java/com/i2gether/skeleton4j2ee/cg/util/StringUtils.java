/* 
 * @ (#) 
 * 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */

package com.i2gether.skeleton4j2ee.cg.util;

public class StringUtils {

	
	public static boolean isValid(String str){
		if(str == null){
			return false;
		}
		
		if(str.trim().length() == 0){
			return false;
		}
		return true;
	}
	
	/**
	 * This method is used to get a block from the content
	 * Say for example content is " This is my content. $DESCRIPTION$ Here is my description $DESCRIPTION$ This is my end content."
	 * Now if the given blockName is "$DESCRIPTION$" then this method will return " Here is my description "
	 * @param content The content where block will be searched
	 * @param blockName The blockName which will be searched
	 * @return then a string which will be inside the given block otherwise it will return empty
	 */
	public static String getBlock(String content, String blockName){
		if(!isValid(content) 
				|| !isValid(blockName)){
			return "";
		}
		
		int blockFirstIndex = content.indexOf(blockName);
		int blockEndIndex = -1;
		if(blockFirstIndex >= 0)
		{
			blockEndIndex = content.indexOf(blockName, blockFirstIndex+blockName.length());
			if(blockEndIndex >=0){
				return content.substring(blockFirstIndex+blockName.length(), blockEndIndex);
			}
		}		
		return "";
	}
	
//	public static void main(String[] args) {
//		String testContent = " This is my content. $DESCRIPTION$ Here is my description $DESCRIPTION$ This is my end content.";
//		String block = getBlock(testContent, "$DESCRIPTION$");
//		System.out.println(block);
//	}
}
