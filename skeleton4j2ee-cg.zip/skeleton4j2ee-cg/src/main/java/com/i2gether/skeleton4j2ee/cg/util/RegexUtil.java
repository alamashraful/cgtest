package com.i2gether.skeleton4j2ee.cg.util;

public class RegexUtil 
{
//	public static final String SVN_FILE_PATTERN = "*.svn";
//	
//	public static boolean isValidSvnFile(String fileName)
//	{
//		Pattern pattern = Pattern.compile(SVN_FILE_PATTERN);
//		Matcher matcher = pattern.matcher(fileName);
//		return matcher.matches();
//	}

	public static boolean isValidSvnFile(String fileName)
	{
		if(fileName == null 
				|| fileName.trim().length() == 0)
		{
			return false;
		}
		
		String nm = fileName.trim().toLowerCase();
		if(nm.contains(".svn"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
