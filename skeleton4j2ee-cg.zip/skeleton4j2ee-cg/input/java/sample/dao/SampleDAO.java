/* 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */

package com.mycompany.myproject.sample.dao;

import java.util.List;

import com.mycompany.myproject.common.dao.BaseEntityDAO;
import com.mycompany.myproject.common.exception.SystemException;
import com.mycompany.myproject.sample.dto.SampleDTO;


public interface SampleDAO<T extends SampleDTO> extends BaseEntityDAO<T> 
{
  enum SampleSortBy {uniqueCode};
  enum SampleWhereCondition {uniqueCode};

  /**
   * This method is used to get Sample List based on groupId and Sample SortBy
   * @param groupId
   * @param sortby
   * @return
   * @throws SystemException
   */
  List<T> getList(Long groupId, SampleSortBy sortby) throws SystemException;	
}
