/* 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */

package com.mycompany.myproject.sample.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mycompany.myproject.sample.dto.SampleDTO;
import com.mycompany.myproject.common.dao.BaseEntityDAOImpl;
import com.mycompany.myproject.common.exception.SystemException;
import com.mycompany.myproject.sample.dao.SampleDAO;


public class SampleDAOImpl extends BaseEntityDAOImpl<SampleDTO> implements SampleDAO<SampleDTO>
{
	private static final Log log = LogFactory.getLog(SampleDAOImpl.class);
		
	@SuppressWarnings("unchecked")
	public List<SampleDTO> getList(Long groupId, SampleSortBy sortby) throws SystemException 
	{
		log.info("getList(groupId,sortby): Enter");
		log.info("getList(groupId,sortby): sortby = "+ sortby);
		
		List<SampleDTO> result = null ;
		StringBuffer queryStr = new StringBuffer();
		queryStr.append("FROM " + SampleDTO.class.getSimpleName() + " entity");
		if(groupId != null)
		{
			queryStr.append(" WHERE entity.groupId="+groupId);	
		}
		queryStr.append(" ORDER BY ");
		queryStr.append(getSortByStr(sortby));

		try
		{	
			result = (List<SampleDTO>) getHibernateTemplate().find(queryStr.toString());
			log.info("getList(groupId,sortby): size = "+ result.size());
		}
		catch (Exception e) 
		{
			throw new SystemException(e);
		}
		log.info("getList(groupId,sortby): Exit");
		return result;
	}
	
	
	private String getSortByStr(SampleSortBy sortBy)
	{
		// default value
		String resultStr = "entity.uniqueCode" ;
		if(sortBy == SampleSortBy.uniqueCode)
		{
			resultStr = "entity.uniqueCode" ;
		}
				
		return resultStr ;		
	}
}
