/* 
 * @ (#) 
 * 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */

package com.mycompany.myproject.sample.action;


import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mycompany.myproject.common.action.BaseAction;
import com.mycompany.myproject.common.exception.BusinessRuleViolationException;
import com.mycompany.myproject.common.exception.SystemException;
import com.mycompany.myproject.common.util.MimeUtils;
import com.mycompany.myproject.common.util.MimeUtils.IMAGE_CONTENT_TYPE;
import com.mycompany.myproject.sample.dto.SampleDTO;
import com.mycompany.myproject.sample.service.SampleService;

public class GetSample extends BaseAction<SampleDTO> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3340580622919258257L;
	private static final Log log = LogFactory.getLog(GetSample.class);
	
	private String fileId;
	private String customContentType;
	private InputStream inputStream;
	private String customContentDisposition;
	private int customContentLength;
	
	public SampleService<SampleDTO> getSampleService() {
		return (SampleService<SampleDTO>)super.getService();
	}

	public void setSampleService(SampleService<SampleDTO> sampleService) {
		//setUserService is must, since it is injected by spring
		//don't change the name, spring looks for 'sampleService' setter method
		super.setService(sampleService);
	}

	@Override
	public String doExecute() throws Exception {
		try {			
			log.info("doExecute(): fileId = " + fileId);
			if(fileId  == null){
				log.warn("doExecute(): fileId is null so returning...");
				return SUCCESS;
			}
			
			SampleDTO sampleDTO = (SampleDTO)getSampleService().get(fileId);
			log.info("doExecute(): sampleDTO = " + sampleDTO);
			if(sampleDTO != null){
				customContentType = sampleDTO.getSampleContentType();
				inputStream = new FileInputStream(getSampleService().getSamplePath(sampleDTO.getUniqueCode()));
				IMAGE_CONTENT_TYPE image_content_type = MimeUtils.getImageContentType(sampleDTO.getSampleContentType());
				if(image_content_type != null){
					customContentDisposition = image_content_type.getContentDisposition("image");
				}
				
				if(sampleDTO.getSampleFileSize() != null){
					customContentLength = (int)sampleDTO.getSampleFileSize().longValue();
				}
			}
			
			
		} catch (SystemException e) {
			log.error("doExecute(): SystemException = ",e);
		} catch (BusinessRuleViolationException e) {
			log.error("doExecute(): BusinessRuleViolationException = ",e);
		}
		
		return SUCCESS;
	}
	
	public InputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getCustomContentType() {
		return customContentType;
	}

	public void setCustomContentType(String customContentType) {
		this.customContentType = customContentType;
	}


	public String getCustomContentDisposition() {
		return customContentDisposition;
	}

	public void setCustomContentDisposition(String customContentDisposition) {
		this.customContentDisposition = customContentDisposition;
	}
	public int getCustomContentLength() {
		return customContentLength;
	}

	public void setCustomContentLength(int customContentLength) {
		this.customContentLength = customContentLength;
	}
	
}
