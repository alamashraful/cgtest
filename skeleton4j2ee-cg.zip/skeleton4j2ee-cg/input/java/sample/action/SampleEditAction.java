/* 
 * @ (#) 
 * 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */

package com.mycompany.myproject.sample.action;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mycompany.myproject.common.ApplicationConstants;
import com.mycompany.myproject.common.util.ValidationUtil;
import com.mycompany.myproject.sample.dto.SampleDTO;

/**
 * This class does the basic validation when user data is added, modified or delete.
 * Validation is added only in addition or modification. 
 */
public class SampleEditAction extends SampleCommonAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4056033732953556639L;
	private static final Log log = LogFactory.getLog(SampleEditAction.class);
	
	//$JAVA_ACTION_VALIDATION_BLOCK$//	
}
