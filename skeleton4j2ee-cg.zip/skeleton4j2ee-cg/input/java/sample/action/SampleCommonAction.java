/* 
 * @ (#) 
 * 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */

package com.mycompany.myproject.sample.action;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mycompany.myproject.common.ApplicationConstants;
import com.mycompany.myproject.common.dto.GenericDTO;
import com.mycompany.myproject.common.search.SearchOperationResult;
import com.mycompany.myproject.common.search.action.BaseSearchAction;
import com.mycompany.myproject.common.web.ForwardNames;
import com.mycompany.myproject.common.web.SESSION_KEYS;
import com.mycompany.myproject.sample.dto.SampleDTO;
import com.mycompany.myproject.sample.service.SampleService;

public class SampleCommonAction extends BaseSearchAction<SampleDTO> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8775802711450477929L;
	private static final Log log = LogFactory.getLog(SampleCommonAction.class);
	
	public SampleService<SampleDTO> getSampleService() {
		return (SampleService<SampleDTO>)super.getService();
	}

	public void setSampleService(SampleService<SampleDTO> sampleService) {
		//setUserService is must, since it is injected by spring
		//don't change the name, spring looks for 'sampleService' setter method
		super.setService(sampleService);
	}
	
	public SampleDTO getSampleDTO() {
		return (SampleDTO)super.getFormDTO();
	}

	public void setSampleDTO(SampleDTO sampleDTO) {
		//setSampleDTO is must, since it is injected by struts
		//don't change the name, struts looks for 'sampleDTO' setter method		
		super.setFormDTO(sampleDTO);
	}
	
	@Override
	public String search()
	{
		log.info("search() : enter : searchQuery = " + searchQuery);	
		try 
		{
			prepareSearchPage();			
			// here we want to load the sample
			String searchSqlQuery = prepareSqlQuery();
			log.info("search(): searchSqlQuery = " + searchSqlQuery);	
			//prepare the request
			prepareRequest();
			
			SearchOperationResult searchOperationResult = getSampleService().search(searchSqlQuery);
			log.info("setSampleFromSystemLevel():: searchOperationResult> size = "+ searchOperationResult.getTotalRowCount());
			String component = "sample";
			String searchResultKey = component + SESSION_KEYS.SEARCH_RESULT_SUFFIX ;
			request.setAttribute(searchResultKey, searchOperationResult);
			request.setAttribute(SESSION_KEYS.IS_SEARCH_RESULT_SHOW, true);
			
			//setting the data for search result page 
			setData(searchOperationResult.getSearchResult());
			
			prepareSearchPage();	
		}
		catch (Exception e)
		{
			log.error("search() :",e);
			addActionError(getText("error.entity.load.systemexception"));
		}
		// show the Sample search page
		return ForwardNames.SEARCH;
	}
	
	private void prepareSearchPage()
	{
		String modifyURL = "sample.action?operationType=prompt&id=";
        request.setAttribute(SESSION_KEYS.MODIFYING_URL, modifyURL )	;
        //request.setAttribute(SESSION_KEYS.COLUMN_HEADER_PAGE, "/Sample/Search/ColumnHeader.jsp");
        request.setAttribute(SESSION_KEYS.COLUMN_HEADER_PAGE_WITH_CHECKBOX, "/Sample/Search/ColumnHeaderWithCheckBox.jsp");
        request.setAttribute(SESSION_KEYS.MODIFYING_URL, modifyURL )	;
	}

	private String prepareSqlQuery()
	{
		boolean isAscending = true ;
		int resultPerPage = ApplicationConstants.SEARCH_RESULT_PER_PAGE ;

		log.info("prepareSqlQuery(): current pagenumber = "+ getCurrentPageNumber());
		int pageNumber = -1;
		try{
			pageNumber = Integer.parseInt(getCurrentPageNumber());
		}catch(NumberFormatException e){}
		
		log.info("prepareSqlQuery(): searchQueryInput = "+ searchQuery);
		if(searchQuery == null){
			searchQuery = "";
		}
		
		String sortOrder = "DESC";
		if(isAscending){
			sortOrder = "ASC";
		} 
		
		int offset = 0;
		if( pageNumber != -1 && pageNumber > 1){
			offset = (pageNumber - 1) * resultPerPage;
	    }
		
		//$JAVA_SEARCH_FUNCTION_SQL_BLOCK1$//
		
		sqlQuery += " a.componentId, a.uniqueCode " + // CUSTOM_FIELDS //
						 	" FROM Samples a WHERE ";		
		sqlQuery += "" +  // $CUSTOM_SEARCH_FIELD1$ //
					" LIKE '%" + searchQuery + "%' ";		
		
		//$JAVA_SEARCH_FUNCTION_SQL_BLOCK2$//		
		
		return sqlQuery;
	}
	
	@Override
	protected GenericDTO createDefaultFormDTO() {
		return new SampleDTO();
	}
}
