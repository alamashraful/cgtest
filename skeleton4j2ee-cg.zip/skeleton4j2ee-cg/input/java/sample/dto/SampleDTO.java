/* 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */
package com.mycompany.myproject.sample.dto;


import com.mycompany.myproject.common.dto.BaseEntity;

/**
 * This DTO represents a Sample object. Sample object
 * is created on an default Organization. 
 */
public class SampleDTO extends BaseEntity
{    
	private static final long serialVersionUID = 1L;
	
	// CUSTOM_FIELDS //
}
