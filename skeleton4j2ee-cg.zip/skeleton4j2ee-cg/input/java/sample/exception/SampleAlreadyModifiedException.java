/* 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */
package com.mycompany.myproject.sample.exception;

import com.mycompany.myproject.common.exception.DuplicateDataException;



/**
 */
public class SampleAlreadyModifiedException extends DuplicateDataException
{
	private static final long serialVersionUID = 1L;

	public SampleAlreadyModifiedException()
    {
        super();
        // TODO Auto-generated constructor stub
    }

    public SampleAlreadyModifiedException(int errorCode, String message)
    {
        super(errorCode, message);
        // TODO Auto-generated constructor stub
    }

    public SampleAlreadyModifiedException(int errorCode)
    {
        super(errorCode);
        // TODO Auto-generated constructor stub
    }

    public SampleAlreadyModifiedException(String message, Throwable cause)
    {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public SampleAlreadyModifiedException(String message)
    {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public SampleAlreadyModifiedException(Throwable cause)
    {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
