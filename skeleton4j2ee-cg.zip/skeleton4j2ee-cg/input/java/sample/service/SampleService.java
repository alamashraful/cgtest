/* 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */

package com.mycompany.myproject.sample.service;
import java.util.List;

import com.mycompany.myproject.common.exception.SystemException;
import com.mycompany.myproject.common.service.GenericService;
import com.mycompany.myproject.sample.dao.SampleDAO.SampleSortBy;
import com.mycompany.myproject.sample.dto.SampleDTO;


/**
 */
public interface SampleService <T extends SampleDTO> extends GenericService<T>
{
	/**
	 * This method is used to get Sample List based on groupId and SampleSortBy 
	 * @param groupId
	 * @param sortby
	 * @return
	 * @throws SystemException
	 */
	List<SampleDTO> getList(Long groupId, SampleSortBy sortby)throws SystemException; 
	
	//$JAVA_SERVICE_INTERFACE_FUNCTION_BLOCK$//
}
