/* 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */

package com.mycompany.myproject.sample.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mycompany.myproject.common.BusinessOperationResult;
import com.mycompany.myproject.common.exception.BusinessRuleViolationException;
import com.mycompany.myproject.common.exception.SystemException;
import com.mycompany.myproject.common.search.BaseSearchService;
//$JAVA_SERVICE_FUNCTION_BLOCK9$//
import com.mycompany.myproject.common.util.ValidationUtil;
import com.mycompany.myproject.sample.SampleSuccessResult;
import com.mycompany.myproject.sample.dao.SampleDAO;
import com.mycompany.myproject.sample.dao.SampleDAO.SampleSortBy;
import com.mycompany.myproject.sample.dto.SampleDTO;
import com.mycompany.myproject.sample.exception.SampleAlreadyExistsException;
import com.mycompany.myproject.sample.exception.SampleAlreadyModifiedException;


/**
 * This class is the implementation of services of Sample entity
 */
public class SampleServiceImpl extends BaseSearchService implements SampleService<SampleDTO>
{
	private static final Log log = LogFactory.getLog(SampleServiceImpl.class);
	
	private SampleDAO<SampleDTO> sampleDAO;	
	
	//$JAVA_SERVICE_FUNCTION_BLOCK1$//
	
	public void setSampleDAO(SampleDAO<SampleDTO> sampleDAO) {
		this.sampleDAO = sampleDAO;
	}
	
	public void validate(SampleDTO sampleDTO) throws BusinessRuleViolationException{		
		
		//checking samplename
		if(!ValidationUtil.isValid(sampleDTO.getUniqueCode())){
			throw new BusinessRuleViolationException("sampleDTO.uniqueCode.required");
		}		
	}
	
	public BusinessOperationResult add(SampleDTO sampleDTO) throws BusinessRuleViolationException, SystemException
	{	
		log.info("add(sampleDTO) : Enter");

		SampleSuccessResult successResult = new SampleSuccessResult();	
		if(sampleDTO == null)
		{
			throw new RuntimeException("Dto must not null");
		}
		
		//$JAVA_SERVICE_FUNCTION_BLOCK2$//
		
		//data validation
		validate(sampleDTO);
		
		// check duplicacy
		boolean isExist = checkUniqueCodeDuplicacy(sampleDTO);
		log.info("add(sampleDTO) : isExist = " + isExist);
		if(isExist)
		{
			throw new SampleAlreadyExistsException("exception.SampleAlreadyExistException");
		}
		
		log.info("add(sampleDTO) : componentId = "+ sampleDTO.getComponentId());
				
		try
		{
			//$JAVA_SERVICE_FUNCTION_BLOCK3$//
			
			//adding default version
			sampleDTO.setVersion(0);
			sampleDAO.add(sampleDTO);
			successResult.setOperationResult(sampleDTO);
		}//$JAVA_SERVICE_FUNCTION_BLOCK7$//
		catch(Exception e){
			log.error("add(sampleDTO) :",e);
			throw new SystemException("operation.failure");
		}
		log.info("add(sampleDTO) : Exit");
		return successResult;
	}
	
	public BusinessOperationResult modify(SampleDTO sampleDTO) throws SystemException, BusinessRuleViolationException{
		
		log.info("modify(sampleDTO) : Enter");
		SampleSuccessResult successResult = new SampleSuccessResult();	
		if(sampleDTO == null)
		{
			throw new SystemException("DTO MUST NOT NULL.");
		}
		
		log.info("modify(sampleDTO) : componentId = "+ sampleDTO.getComponentId());
		
		if(sampleDTO.getComponentId() <= 0){
			throw new RuntimeException("operation.failure");
		}
		
		//data validation
		validate(sampleDTO);

		try
		{
			//checking dirty data handling
			SampleDTO existing = sampleDAO.get(SampleDTO.class, sampleDTO.getComponentId());
			
			//checking same object or both null
			if(sampleDTO.getVersion() == existing.getVersion()){ 
				//no one is updated yet. so we are going to update it.
			}else{
				
				//now checking the real value of both, since they are object
				if(sampleDTO.getVersion() != null 
						&& existing.getVersion() != null
						&& sampleDTO.getVersion().intValue() == existing.getVersion().intValue()){
					//no one is updated yet. so we are going to update it.
				}else{
					log.info("modify(sampleDTO) : existing data in db is already modified.");
					throw new SampleAlreadyModifiedException("operation.failure");
				}
			}
			
			String uniqueCode = existing.getUniqueCode();
			if(uniqueCode != null 
					&& uniqueCode.equalsIgnoreCase(sampleDTO.getUniqueCode())){
				;//data is valid for update now
			}else{

				// check duplicacy
				boolean isExist = checkUniqueCodeDuplicacy(sampleDTO);
				log.info("modify(sampleDTO) : isExist = " + isExist);
				if(isExist)
				{
					throw new SampleAlreadyExistsException("exception.SampleAlreadyExistException");
				}				
			}
			
			//$JAVA_SERVICE_FUNCTION_BLOCK4$//
			
			//now we need to update the existing data
			//assuming that in when data is modifying, updatedby and updateddate is already filled in sampleDTO.
			sampleDTO.setStatus(existing.getStatus());
			sampleDTO.setCreatedBy(existing.getCreatedBy());
			sampleDTO.setCreatedDate(existing.getCreatedDate());
			if(existing.getVersion() != null){
				sampleDTO.setVersion(existing.getVersion() + 1);
			}else{
				sampleDTO.setVersion(0);
			}
			
			//$JAVA_SERVICE_FUNCTION_BLOCK5$//
			
			sampleDAO.update(sampleDTO);
			successResult.setOperationResult(sampleDTO);
			
		}catch(SampleAlreadyModifiedException e){
			log.warn("modify(sampleDTO) :",e);
			throw e;
		}catch(SampleAlreadyExistsException e){
			log.warn("modify(sampleDTO) :",e);
			throw e;
		}//$JAVA_SERVICE_FUNCTION_BLOCK8$//		
		catch(Exception e){
			log.error("modify(sampleDTO) :",e);
			throw new SystemException("operation.failure");
		}
		log.info("modify(sampleDTO) : Exit");
		return successResult;
	}
		
	public BusinessOperationResult remove(SampleDTO sampleDTO) throws SystemException, BusinessRuleViolationException
	{
		log.info("remove(sampleDTO) : Enter");
		SampleSuccessResult successResult = new SampleSuccessResult();	
		if(sampleDTO == null)
		{
			throw new RuntimeException("DTO MUST NOT NULL.");
		}
		
		log.info("remove(sampleDTO) : code = "+ sampleDTO.getUniqueCode());
		log.info("remove(sampleDTO) : componentId = "+ sampleDTO.getComponentId());
		
		try
		{
			//$JAVA_SERVICE_FUNCTION_BLOCK6$//
			
			sampleDAO.delete(sampleDTO);
			successResult.setOperationResult(sampleDTO);
		}
		catch(Exception e)
		{
			log.error("remove(sampleDTO) :",e);
			throw new SystemException(e);
		}
		log.info("remove(sampleDTO) : Exit");
		return successResult;
	}
	
	public SampleDTO get(Long componentId) throws SystemException
	{
		log.info("get(componentId) : Enter");
		log.info("get(componentId) : componentId = " + componentId);
		SampleDTO sampleDTO = null;		
		try
		{
			sampleDTO = sampleDAO.get(SampleDTO.class, componentId);
		}
		catch (RuntimeException e) 
		{
			log.error("get(componentId)",e);
			throw new SystemException(e);
		}
		log.info("get(componentId) : Exit");
		return sampleDTO;
	}
	
	public SampleDTO get(String uniqueCode) throws BusinessRuleViolationException, SystemException  
	{
		log.info("get(uniqueCode) : Enter");
		SampleDTO sampleDTO = null;		
		try{
			sampleDTO = sampleDAO.get(SampleDTO.class, uniqueCode);
		}catch (Exception e) {
			log.error("get(uniqueCode)",e);
			throw new SystemException(e);
		}	
		log.info("get(uniqueCode) : Exit");
		return sampleDTO;
	}

	
	 public List<SampleDTO> getList(Long groupId, SampleSortBy sortby)throws SystemException
	 {
		log.info("getList(groupId,sortby) : Enter");
		List<SampleDTO> result = null ;
		try
		{
			result = sampleDAO.getList(groupId,sortby);
		}
		catch (Exception e) 
		{
			log.error("getList(groupId,sortby)",e);
			throw new SystemException(e);
		}	
		log.info("getList(groupId,sortby) : Exit");
		return result; 
	 }
	 
	 public List<SampleDTO> getList()throws SystemException
	 {
		log.info("getList() : Enter");
		List<SampleDTO> result = null ;
		try
		{
			result = sampleDAO.getList(SampleDTO.class) ;
		}
		catch (Exception e) 
		{
			log.error("getList()",e);
			throw new SystemException(e);
		}	
		log.info("getList() : Exit");
		return result; 
	 }
	 	
	private boolean checkUniqueCodeDuplicacy(SampleDTO sampleDTO) throws SystemException
	{
		boolean isExist = false ;
		try 
		{
			sampleDTO = sampleDAO.get(SampleDTO.class, sampleDTO.getUniqueCode());
			if(sampleDTO != null)
			{
				isExist =  true ;	
			}
		}
		catch (SystemException e)
		{
			throw e ;
		}
		return isExist ;		
	}
	
	public BusinessOperationResult remove(List<SampleDTO> entityList) throws SystemException, BusinessRuleViolationException 
	{
		log.info("remove(entityList) : Enter");
		SampleSuccessResult successResult = new SampleSuccessResult();	
		if(entityList == null || entityList.size() == 0)
		{
			//nothing to do
			return successResult;
		}
				
		log.info("remove(entityList) : entityList.size = " + entityList.size());
		try
		{
			sampleDAO.delete(entityList);
			successResult.setData(entityList);
		}
		catch(Exception e)
		{
			log.error("remove(entityList) :",e);
			throw new SystemException(e);
		}
		log.info("remove(entityList) : Exit");
		return successResult;
	}

	public BusinessOperationResult removeByIds(List<Long> ids)
			throws SystemException, BusinessRuleViolationException {
		log.info("remove(ids) : Enter");
		SampleSuccessResult successResult = new SampleSuccessResult();	
		if(ids == null || ids.size() == 0)
		{
			//nothing to do
			return successResult;
		}
				
		log.info("remove(ids) : ids.size = " + ids.size());
		try
		{
			sampleDAO.delete(SampleDTO.class, ids);
			successResult.setData(ids);
		}
		catch(Exception e)
		{
			log.error("remove(ids) :",e);
			throw new SystemException(e);
		}
		log.info("remove(ids) : Exit");
		return successResult;
	}

	public BusinessOperationResult add(List<SampleDTO> entityList)
			throws SystemException, BusinessRuleViolationException {
		log.info("add(entityList) : Enter");
		SampleSuccessResult successResult = new SampleSuccessResult();	
		if(entityList == null || entityList.size() == 0)
		{
			//nothing to do
			return successResult;
		}
			
		log.info("add(entityList) : entityList.size = " + entityList.size());
		try
		{
			sampleDAO.add(entityList);
			successResult.setData(entityList);
		}
		catch(Exception e)
		{
			log.error("add(entityList) :",e);
			throw new SystemException(e);
		}
		log.info("add(entityList) : Exit");
		return successResult;
	}

	public BusinessOperationResult modify(List<SampleDTO> entityList)
			throws SystemException, BusinessRuleViolationException {
		log.info("modify(entityList) : Enter");
		SampleSuccessResult successResult = new SampleSuccessResult();	
		if(entityList == null || entityList.size() == 0)
		{
			//nothing to do
			return successResult;
		}
			
		log.info("modify(entityList) : entityList.size = " + entityList.size());
		try
		{
			sampleDAO.update(entityList);
			successResult.setData(entityList);
		}
		catch(Exception e)
		{
			log.error("modify(entityList) :",e);
			throw new SystemException(e);
		}
		log.info("modify(entityList) : Exit");
		return successResult;
	}

}
