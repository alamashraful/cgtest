/* 
 * Copyright (c) 2011 Together Initiatives Ltd. All Rights Reserved. This software is the
 * confidential and proprietary information of Together Initiatives Ltd ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Together Initiatives Ltd.
 */

package com.mycompany.myproject.sample;

import com.mycompany.myproject.sample.dto.SampleDTO;
import com.mycompany.myproject.common.BusinessOperationResult;

/**
 */
public class SampleSuccessResult extends BusinessOperationResult
{
	private static final long serialVersionUID = 1L;
	private SampleDTO operationResult;

	public SampleDTO getOperationResult()
	{
		return operationResult;
	}

	public void setOperationResult(SampleDTO operationResult)
	{
		this.operationResult = operationResult;
	}		 
}
