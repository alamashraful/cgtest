CREATE TABLE Samples (
  componentId BIGINT NOT NULL #$SQL_ID_GENERATOR$#,
  uniqueCode VARCHAR(50),  

# CUSTOM_FIELDS #
    
   status INT NOT NULL DEFAULT 0,
   version INT DEFAULT 0,
   createddate DATETIME DEFAULT NULL,
   createdby BIGINT DEFAULT NULL,
   updateddate DATETIME DEFAULT NULL,
   updatedby BIGINT DEFAULT NULL,
   PRIMARY KEY (componentId)
)